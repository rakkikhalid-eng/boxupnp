plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rakki.boxdlna"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rakki.boxdlna"
        minSdk = 24
        targetSdk = 33
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt() + 10
        versionName = "2.6"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }
    signingConfigs {
        create("fixed") {
            val ks = file("boxdlna.keystore")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "boxdlna"
                keyAlias = "boxdlna"
                keyPassword = "boxdlna"
            }
        }
    }
    buildTypes {
        getByName("debug") {
            val ks = file("boxdlna.keystore")
            if (ks.exists()) {
                signingConfig = signingConfigs.getByName("fixed")
            }
        }
        release {
            isMinifyEnabled = false
            val ks = file("boxdlna.keystore")
            if (ks.exists()) {
                signingConfig = signingConfigs.getByName("fixed")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi"
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}
