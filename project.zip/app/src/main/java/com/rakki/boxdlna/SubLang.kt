package com.rakki.boxdlna

import java.io.File

/** Very small language guesser for subtitle text (script + common words), to name subtitle entries. */
object SubLang {
    private val words = mapOf(
        "fre" to setOf("le", "la", "les", "des", "est", "une", "pas", "que", "qui", "vous", "je", "nous", "dans", "pour", "ce", "il", "elle", "ne", "au", "du", "avec", "sur", "mais", "tu", "pas", "être"),
        "eng" to setOf("the", "and", "you", "that", "is", "to", "of", "it", "not", "are", "with", "for", "this", "have", "what", "was", "but", "they", "your", "don't", "i'm", "he", "she"),
        "spa" to setOf("el", "los", "las", "una", "que", "por", "para", "con", "no", "es", "está", "pero", "yo", "tú", "usted", "muy", "como", "qué"),
        "ger" to setOf("der", "die", "das", "und", "ist", "nicht", "ich", "sie", "mit", "ein", "eine", "du", "wir", "aber", "was"),
        "ita" to setOf("il", "lo", "gli", "che", "non", "sono", "una", "per", "con", "ma", "io", "tu", "è", "questo", "come"),
        "por" to setOf("o", "os", "as", "um", "uma", "que", "não", "para", "com", "mas", "eu", "você", "é", "está", "como"),
        "tur" to setOf("bir", "bu", "ve", "ne", "ben", "sen", "için", "var", "değil", "ama", "çok", "evet", "hayır")
    )

    /** Returns an OpenSubtitles-style 3-letter code, or "" when unsure. */
    fun detect(text: String): String {
        val sample = text.take(60000)
        var letters = 0
        var arabic = 0
        var cyr = 0
        var hebrew = 0
        var cjk = 0
        for (ch in sample) {
            if (!ch.isLetter()) continue
            letters++
            when (ch) {
                in '\u0600'..'\u06FF' -> arabic++
                in '\u0400'..'\u04FF' -> cyr++
                in '\u0590'..'\u05FF' -> hebrew++
                in '\u3040'..'\u9FFF', in '\uAC00'..'\uD7AF' -> cjk++
            }
        }
        if (letters < 30) return ""
        if (arabic * 100 / letters > 40) return "ara"
        if (cyr * 100 / letters > 40) return "rus"
        if (hebrew * 100 / letters > 40) return "heb"
        if (cjk * 100 / letters > 40) return "cjk"
        val toks = Regex("[\\p{L}']+").findAll(sample.lowercase()).map { it.value }.toList()
        if (toks.size < 20) return ""
        var best = ""
        var bestN = 0
        var second = 0
        for ((code, set) in words) {
            val n = toks.count { it in set }
            if (n > bestN) { second = bestN; bestN = n; best = code } else if (n > second) second = n
        }
        return if (bestN >= 8 && bestN > second * 1.25) best else ""
    }

    fun detectFile(path: String): String = try {
        File(path).inputStream().use { s ->
            val buf = ByteArray(60000)
            val n = s.read(buf)
            detect(String(buf, 0, maxOf(n, 0), Charsets.UTF_8))
        }
    } catch (e: Exception) { "" }

    fun name(code: String): String = when (code) {
        "ara" -> L.t("lang_ara")
        "fre" -> L.t("lang_fre")
        "eng" -> L.t("lang_eng")
        "spa" -> "Español"
        "ger" -> "Deutsch"
        "ita" -> "Italiano"
        "por" -> "Português"
        "tur" -> "Türkçe"
        "rus" -> "Русский"
        "heb" -> "עברית"
        "cjk" -> "中文 / 日本語 / 한국어"
        else -> ""
    }
}
