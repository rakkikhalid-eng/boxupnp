package com.rakki.boxdlna

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

object Renderer {
    val main = Handler(Looper.getMainLooper())

    @Volatile var uri = ""
    @Volatile var meta = ""
    @Volatile var subUrl: String? = null
    @Volatile var state = "NO_MEDIA_PRESENT"
    @Volatile var posMs = 0L
    @Volatile var durMs = 0L
    @Volatile var wantPlay = false
    @Volatile var startMs = 0L
    @Volatile var activity: PlayerActivity? = null
    @Volatile var manual: SubtitleLoader.Sub? = null
    @Volatile var manualUri = ""
    @Volatile var onChange: (() -> Unit)? = null

    fun changed() { onChange?.invoke() }

    fun setUri(u: String, m: String) {
        uri = u; meta = m
        subUrl = extractSubtitle(m)
        posMs = 0; durMs = 0; wantPlay = false; startMs = 0
        if (u.isNotEmpty() && manualUri == "*") manualUri = u
        state = if (u.isEmpty()) "NO_MEDIA_PRESENT" else "STOPPED"
        main.post { activity?.player?.pause() }
        changed()
    }

    fun applyManual(s: SubtitleLoader.Sub) {
        manual = s
        manualUri = if (uri.isNotEmpty() && activity != null) uri else "*"
        main.post { activity?.reloadSubs() }
    }

    fun effectiveManual(): SubtitleLoader.Sub? = manual?.takeIf { manualUri == uri }

    fun signature(): String = uri + "|" + (effectiveManual()?.file?.name ?: subUrl ?: "")

    fun play(ctx: Context) {
        if (uri.isEmpty()) return
        wantPlay = true
        if (state != "PLAYING") { state = "TRANSITIONING"; changed() }
        val a = activity
        if (a != null) main.post { a.onPlayRequest() }
        try {
            ctx.startActivity(Intent(ctx, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    fun pause() { main.post { activity?.player?.pause() } }

    fun stop() {
        wantPlay = false
        state = if (uri.isEmpty()) "NO_MEDIA_PRESENT" else "STOPPED"
        posMs = 0
        main.post { activity?.finish() }
        changed()
    }

    fun seek(ms: Long) { main.post { activity?.player?.seekTo(ms) } }
}
