package com.rakki.boxdlna

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Automatic subtitle sync without any server: the player's PCM audio is measured (10 ms energy bins),
 * turned into a "someone is speaking" signal, then cross-correlated with the "a subtitle is on screen"
 * signal. The offset with the best match is applied.
 */
object AutoSync {
    private val lock = Any()
    private val bins = ArrayList<Float>()
    private var curSum = 0.0
    private var curCnt = 0
    private var binFrames = 480
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT

    @Volatile var collecting = false
    @Volatile var pendingRefMs = 0L
    @Volatile var refMs = 0L

    fun begin(posMs: Long) {
        synchronized(lock) { bins.clear(); curSum = 0.0; curCnt = 0 }
        pendingRefMs = posMs
        refMs = posMs
        collecting = true
    }

    fun end(): FloatArray {
        collecting = false
        synchronized(lock) { return bins.toFloatArray() }
    }

    fun binCount(): Int = synchronized(lock) { bins.size }

    val processor: AudioProcessor = object : BaseAudioProcessor() {
        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            encoding = inputAudioFormat.encoding
            channels = maxOf(1, inputAudioFormat.channelCount)
            binFrames = maxOf(1, inputAudioFormat.sampleRate / 100)
            return inputAudioFormat
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val n = inputBuffer.remaining()
            if (n == 0) return
            if (collecting && encoding == C.ENCODING_PCM_16BIT) {
                try { analyze(inputBuffer.duplicate()) } catch (e: Exception) { }
            }
            val out = replaceOutputBuffer(n)
            out.put(inputBuffer)
            out.flip()
        }

        override fun onFlush() {
            if (collecting) {
                synchronized(lock) { bins.clear(); curSum = 0.0; curCnt = 0 }
                refMs = pendingRefMs
            }
        }
    }

    private fun analyze(b: ByteBuffer) {
        b.order(ByteOrder.LITTLE_ENDIAN)
        val sb = b.asShortBuffer()
        synchronized(lock) {
            while (sb.remaining() >= channels) {
                var acc = 0
                for (i in 0 until channels) acc += sb.get().toInt()
                val m = acc.toDouble() / channels / 32768.0
                curSum += m * m
                curCnt++
                if (curCnt >= binFrames) {
                    bins.add(sqrt(curSum / curCnt).toFloat())
                    curSum = 0.0
                    curCnt = 0
                }
            }
        }
    }

    class Result(val offsetMs: Long, val ok: Boolean)

    /** [bins] are 10 ms RMS values starting at media time [startMs]. Returns the subtitle offset (ms). */
    fun solve(bins: FloatArray, startMs: Long, cues: List<CueParser.C>): Result {
        if (cues.isEmpty() || bins.size < 3000) return Result(0, false)
        // 100 ms speech signal from audio
        val n = bins.size / 10
        val e = FloatArray(n)
        for (i in 0 until n) {
            var s = 0f
            for (j in 0 until 10) s += bins[i * 10 + j]
            e[i] = s / 10f
        }
        val sorted = e.sortedArray()
        val lo = sorted[(n * 0.2).toInt()]
        val hi = sorted[(n * 0.9).toInt().coerceAtMost(n - 1)]
        if (hi - lo < 1e-4f) return Result(0, false)
        val thr = lo + 0.25f * (hi - lo)
        val a = FloatArray(n) { if (e[it] > thr) 1f else 0f }
        val aMean = a.average().toFloat()
        if (aMean < 0.05f || aMean > 0.95f) return Result(0, false)

        // 100 ms subtitle signal covering [start - R, end + R]
        val range = 600 // +-60 s in 100 ms steps
        val startBin = startMs / 100
        val from = startBin - range
        val len = n + 2 * range
        val sig = FloatArray(len)
        for (c in cues) {
            val s = (c.s / 100 - from).toInt().coerceIn(0, len)
            val en = ((c.e + 99) / 100 - from).toInt().coerceIn(0, len)
            for (i in s until en) sig[i] = 1f
        }

        val scores = FloatArray(2 * range + 1)
        for (k in -range..range) {
            // audio bin i (time startBin + i) pairs with subtitle time (startBin + i - k)
            var sumS = 0f
            var sumAS = 0f
            for (i in 0 until n) {
                val v = sig[i - k + range]
                sumS += v
                sumAS += a[i] * v
            }
            val sMean = sumS / n
            scores[k + range] = sumAS - n * aMean * sMean
        }
        var best = 0
        for (i in scores.indices) if (scores[i] > scores[best]) best = i
        var second = Float.NEGATIVE_INFINITY
        for (i in scores.indices) if (abs(i - best) > 10 && scores[i] > second) second = scores[i]
        val ok = scores[best] > 0f && (second <= 0f || scores[best] >= 1.15f * second)
        return Result((best - range) * 100L, ok)
    }
}
