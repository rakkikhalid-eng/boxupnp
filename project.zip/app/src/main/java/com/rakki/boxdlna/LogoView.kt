package com.rakki.boxdlna

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** App mark: glowing disc, play triangle and three "cast" waves. */
class LogoView(ctx: Context) : View(ctx) {
    /** 0..1 – how far the waves have expanded. */
    var waves = 1f
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w, h)
        val cx = w / 2
        val cy = h / 2
        val r = s * 0.30f

        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, s * 0.5f, intArrayOf(0x663B82F6, 0x00000000), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, s * 0.5f, p)

        p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFF60A5FA.toInt(), 0xFF1D4ED8.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        p.shader = null

        p.color = 0xFFFFFFFF.toInt()
        path.reset()
        path.moveTo(cx - r * 0.25f, cy - r * 0.48f)
        path.lineTo(cx + r * 0.50f, cy)
        path.lineTo(cx - r * 0.25f, cy + r * 0.48f)
        path.close()
        c.drawPath(path, p)

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.026f
        for (i in 0..2) {
            val rr = r + s * (0.075f + 0.065f * i) * (0.6f + 0.4f * waves)
            val a = (255 * waves * (1f - 0.25f * i)).toInt().coerceIn(0, 255)
            p.color = (a shl 24) or 0x00BFDBFE
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            c.drawArc(rect, -42f, 84f, false, p)
        }
    }
}
