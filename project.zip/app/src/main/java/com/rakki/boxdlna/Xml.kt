package com.rakki.boxdlna

import java.util.Locale

fun esc(s: String): String =
    s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

fun unesc(s: String): String =
    s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

fun hms(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

fun parseTime(t: String): Long? {
    val p = t.trim().split(":")
    if (p.size != 3) return null
    return try {
        ((p[0].toLong() * 3600 + p[1].toLong() * 60) * 1000 + (p[2].toDouble() * 1000).toLong())
    } catch (e: Exception) { null }
}

private val subRegexes = listOf(
    Regex("""<sec:CaptionInfoEx[^>]*>\s*([^<]+?)\s*</sec:CaptionInfoEx>"""),
    Regex("""<sec:CaptionInfo[^>]*>\s*([^<]+?)\s*</sec:CaptionInfo>"""),
    Regex("""<pv:subtitleFileUri>\s*([^<]+?)\s*</pv:subtitleFileUri>"""),
    Regex("""<res[^>]*(?:text/srt|subrip|text/vtt|x-subtitle|smi)[^>]*>\s*([^<]+?)\s*</res>""", RegexOption.IGNORE_CASE),
    Regex("""<res[^>]*>\s*([^<]+?\.(?:srt|vtt|ass|ssa))\s*</res>""", RegexOption.IGNORE_CASE)
)

fun extractSubtitle(meta: String): String? {
    for (r in subRegexes) {
        val m = r.find(meta)
        if (m != null) return unesc(m.groupValues[1])
    }
    return null
}
