package com.rakki.boxdlna

import android.content.Context

/** Small settings store (OpenSubtitles API credentials). */
object Cfg {
    private fun p(c: Context) = c.getSharedPreferences("box", Context.MODE_PRIVATE)
    fun apiKey(c: Context): String = p(c).getString("osKey", "") ?: ""
    fun user(c: Context): String = p(c).getString("osUser", "") ?: ""
    fun pass(c: Context): String = p(c).getString("osPass", "") ?: ""
    fun save(c: Context, key: String, user: String, pass: String) {
        p(c).edit().putString("osKey", key.trim()).putString("osUser", user.trim()).putString("osPass", pass).apply()
    }
}
