package com.rakki.boxdlna

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Keeps every subtitle applied to a video (downloaded or sent from the phone) so it can be picked again later. */
object SubHistory {
    class Entry(val path: String, val label: String, val time: Long)

    private const val MAX_PER_VIDEO = 12
    private const val SEP = "__"

    private fun dir(c: Context): File = File(c.filesDir, "subs").also { it.mkdirs() }
    private fun vkey(@Suppress("UNUSED_PARAMETER") uri: String): String = Integer.toHexString(Renderer.videoKey().hashCode())

    fun save(c: Context?, uri: String, s: SubtitleLoader.Sub, label: String): String {
        if (c == null || uri.isEmpty()) return ""
        return try {
            val bytes = s.file.readBytes()
            val h = MessageDigest.getInstance("MD5").digest(bytes).joinToString("") { "%02x".format(it) }.take(10)
            val k = vkey(uri)
            val d = dir(c)
            val existing = d.listFiles()?.firstOrNull { it.name.startsWith(k + SEP + h + SEP) }
            if (existing != null) {
                existing.setLastModified(System.currentTimeMillis())
                return existing.absolutePath
            }
            val lab = label.ifEmpty { "subtitle" }.replace(Regex("[^\\p{L}\\p{N} ._()-]"), "_").replace("__", "_").take(60)
            val f = File(d, k + SEP + h + SEP + System.currentTimeMillis() + SEP + lab + ".srt")
            f.writeBytes(bytes)
            prune(d, k)
            f.absolutePath
        } catch (e: Exception) { "" }
    }

    fun list(c: Context?, uri: String): List<Entry> {
        if (c == null || uri.isEmpty()) return emptyList()
        val k = vkey(uri)
        val files = dir(c).listFiles()?.filter { it.name.startsWith(k + SEP) } ?: return emptyList()
        return files.sortedByDescending { it.lastModified() }.take(MAX_PER_VIDEO).map {
            val parts = it.name.removeSuffix(".srt").split(SEP, limit = 4)
            Entry(it.absolutePath, parts.getOrNull(3) ?: it.name, it.lastModified())
        }
    }

    private fun prune(d: File, k: String) {
        val all = d.listFiles() ?: return
        all.filter { it.name.startsWith(k + SEP) }.sortedByDescending { it.lastModified() }.drop(MAX_PER_VIDEO).forEach { it.delete() }
        if (all.size > 300) all.sortedBy { it.lastModified() }.take(all.size - 300).forEach { it.delete() }
    }
}
