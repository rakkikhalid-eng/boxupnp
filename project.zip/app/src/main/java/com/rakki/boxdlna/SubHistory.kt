package com.rakki.boxdlna

import android.content.Context
import java.io.File
import java.security.MessageDigest

/**
 * Keeps every subtitle applied to a video (sent by the app, downloaded, uploaded) so it can be picked again later.
 * File name: <video>__<content hash>__<time>__<language>__<label>.srt  (the language is stored once, never re-detected).
 */
object SubHistory {
    class Entry(val path: String, val label: String, val time: Long, val lang: String)

    private const val MAX_PER_VIDEO = 12
    private const val SEP = "__"

    private fun dir(c: Context): File = File(c.filesDir, "subs").also { it.mkdirs() }
    private fun vkey(@Suppress("UNUSED_PARAMETER") uri: String): String = Integer.toHexString(Renderer.videoKey().hashCode())

    fun save(c: Context?, uri: String, s: SubtitleLoader.Sub, label: String, lang: String = ""): String {
        if (c == null || uri.isEmpty()) return ""
        return try {
            val bytes = s.file.readBytes()
            val h = MessageDigest.getInstance("MD5").digest(bytes).joinToString("") { "%02x".format(it) }.take(10)
            val k = vkey(uri)
            val d = dir(c)
            val existing = d.listFiles()?.firstOrNull { it.name.startsWith(k + SEP + h + SEP) }
            if (existing != null) {
                existing.setLastModified(System.currentTimeMillis())
                return existing.absolutePath
            }
            val code = lang.ifEmpty { SubLang.detect(String(bytes, 0, minOf(bytes.size, 60000), Charsets.UTF_8)) }.ifEmpty { "-" }
            val lab = label.ifEmpty { "subtitle" }.replace(Regex("[^\\p{L}\\p{N} ._()-]"), "_").replace("__", "_").take(60)
            val f = File(d, k + SEP + h + SEP + System.currentTimeMillis() + SEP + code + SEP + lab + ".srt")
            f.writeBytes(bytes)
            prune(d, k)
            f.absolutePath
        } catch (e: Exception) { "" }
    }

    fun list(c: Context?, uri: String): List<Entry> {
        if (c == null || uri.isEmpty()) return emptyList()
        val k = vkey(uri)
        val files = dir(c).listFiles()?.filter { it.name.startsWith(k + SEP) } ?: return emptyList()
        return files.sortedByDescending { it.lastModified() }.take(MAX_PER_VIDEO).map {
            val parts = it.name.removeSuffix(".srt").split(SEP, limit = 5)
            if (parts.size == 5) Entry(it.absolutePath, parts[4], it.lastModified(), parts[3].takeIf { l -> l != "-" } ?: "")
            else Entry(it.absolutePath, parts.getOrNull(3) ?: it.name, it.lastModified(), "")   // older files
        }
    }

    fun countAll(c: Context?): Int = if (c == null) 0 else (dir(c).listFiles()?.size ?: 0)

    fun clearAll(c: Context?) {
        if (c == null) return
        dir(c).listFiles()?.forEach { it.delete() }
    }

    /** "base", then "base (2)", "base (3)"... so each different subtitle keeps its own entry. */
    fun nextLabel(c: Context?, uri: String, base: String): String {
        val n = list(c, uri).count { it.label == base || it.label.startsWith("$base (") }
        return if (n == 0) base else "$base (" + (n + 1) + ")"
    }

    private fun prune(d: File, k: String) {
        val all = d.listFiles() ?: return
        all.filter { it.name.startsWith(k + SEP) }.sortedByDescending { it.lastModified() }.drop(MAX_PER_VIDEO).forEach { it.delete() }
        if (all.size > 300) all.sortedBy { it.lastModified() }.take(all.size - 300).forEach { it.delete() }
    }
}
