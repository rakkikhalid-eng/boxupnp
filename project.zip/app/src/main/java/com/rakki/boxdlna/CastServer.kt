package com.rakki.boxdlna

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket

class CastServer(
    private val ctx: Context,
    private val udn: String,
    private val volGet: () -> Int,
    private val volSet: (Int) -> Unit
) {
    companion object {
        const val PORT = 8009
        const val NS_AUTH = "urn:x-cast:com.google.cast.tp.deviceauth"
        const val NS_CONN = "urn:x-cast:com.google.cast.tp.connection"
        const val NS_HB = "urn:x-cast:com.google.cast.tp.heartbeat"
        const val NS_RECV = "urn:x-cast:com.google.cast.receiver"
        const val NS_MEDIA = "urn:x-cast:com.google.cast.media"
    }

    private class Conn(val sock: Socket) {
        private val out = DataOutputStream(sock.getOutputStream())
        fun send(src: String, dst: String, ns: String, text: String? = null, bin: ByteArray? = null) {
            val b = CastProto.encode(CastProto.Msg(src, dst, ns, if (text != null) 0 else 1, text, bin))
            synchronized(this) {
                out.writeInt(b.size)
                out.write(b)
                out.flush()
            }
        }
    }

    @Volatile private var alive = false
    private var server: SSLServerSocket? = null
    private val conns = CopyOnWriteArrayList<Conn>()
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null

    @Volatile private var sessionId: String? = null
    @Volatile private var transportId = ""
    @Volatile private var appId = "CC1AD845"
    @Volatile private var contentType = "video/mp4"

    fun start(friendly: String) {
        if (alive) return
        alive = true
        try {
            val key = KeyFactory.getInstance("RSA").generatePrivate(
                PKCS8EncodedKeySpec(ctx.assets.open("cast_key.der").use { it.readBytes() })
            )
            val cert = ctx.assets.open("cast_cert.der").use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
            val ks = KeyStore.getInstance(KeyStore.getDefaultType())
            ks.load(null, null)
            val pw = "boxchrome".toCharArray()
            ks.setKeyEntry("k", key, pw, arrayOf(cert))
            val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
            kmf.init(ks, pw)
            val sc = SSLContext.getInstance("TLS")
            sc.init(kmf.keyManagers, null, null)
            
            val ss = sc.serverSocketFactory.createServerSocket(PORT) as SSLServerSocket
            ss.reuseAddress = true
            ss.enabledProtocols = arrayOf("TLSv1", "TLSv1.1", "TLSv1.2", "TLSv1.3")
            server = ss
            CastDiag.tls = "TLS: يستمع مرن على 8009 ✓"

            Thread {
                while (alive) {
                    val s = try { ss.accept() as SSLSocket } catch (e: Exception) { break }
                    try {
                        s.enableSessionCreation = true
                        s.startHandshake()
                    } catch (e: Exception) {
                        continue
                    }
                    CastDiag.conns++
                    Thread { serve(s) }.start()
                }
            }.start()
        } catch (e: Exception) {
            CastDiag.tls = "TLS فشل: " + e.message?.take(40)
        }

        register(friendly)
    }

    fun stop() {
        alive = false
        try { server?.close() } catch (e: Exception) { }
        for (c in conns) try { c.sock.close() } catch (e: Exception) { }
        try { reg?.let { nsd?.unregisterService(it) } } catch (e: Exception) { }
    }

    fun onStateChanged() {
        if (alive && sessionId != null) broadcastMedia(0)
    }

    private fun register(friendly: String) {
        try {
            val id = udn.replace("-", "")
            val si = NsdServiceInfo()
            si.serviceName = "BoxChrome-" + id.take(12)
            si.serviceType = "_googlecast._tcp"
            si.port = PORT
            si.setAttribute("id", id)
            si.setAttribute("cd", id)
            si.setAttribute("ve", "05")
            si.setAttribute("md", "Chromecast")
            si.setAttribute("fn", friendly)
            si.setAttribute("ca", "4101")
            si.setAttribute("st", "0")
            
            val l = object : NsdManager.RegistrationListener {
                override fun onRegistrationFailed(s: NsdServiceInfo?, code: Int) { CastDiag.mdns = "mDNS: فشل" }
                override fun onUnregistrationFailed(s: NsdServiceInfo?, code: Int) { }
                override fun onServiceRegistered(s: NsdServiceInfo?) { CastDiag.mdns = "mDNS: مسجّل ✓" }
                override fun onServiceUnregistered(s: NsdServiceInfo?) { }
            }
            val m = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
            nsd = m
            reg = l
            m.registerService(si, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) { }
    }

    private fun serve(sock: Socket) {
        val c = Conn(sock)
        conns.add(c)
        try {
            sock.soTimeout = 60000
            val inp = DataInputStream(BufferedInputStream(sock.getInputStream()))
            while (alive) {
                val len = inp.readInt()
                if (len <= 0 || len > 2_000_000) break
                val buf = ByteArray(len)
                inp.readFully(buf)
                val m = CastProto.decode(buf) ?: continue
                try { handle(c, m) } catch (e: Exception) { }
            }
        } catch (e: Exception) {
        } finally {
            conns.remove(c)
            try { sock.close() } catch (e: Exception) { }
        }
    }

    private fun json(m: CastProto.Msg): JSONObject = try { JSONObject(m.text ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun handle(c: Conn, m: CastProto.Msg) {
        CastDiag.last = m.ns.substringAfterLast('.') + " " + (if (m.type == 0) json(m).optString("type") else "binary")
        when (m.ns) {
            NS_AUTH -> {
                c.send(m.dst, m.src, NS_AUTH, bin = byteArrayOf(0x0A, 0x04, 0x08, 0x96, 0x01, 0x10, 0x02))
            }
            NS_HB -> if (json(m).optString("type") == "PING") c.send(m.dst, m.src, NS_HB, "{"type":"PONG"}")
            NS_RECV -> receiver(c, m)
            NS_MEDIA -> media(c, m)
            else -> { }
        }
    }

    private fun receiverStatus(rid: Int): String {
        val apps = JSONArray()
        val sid = sessionId
        if (sid != null) {
            apps.put(
                JSONObject().put("appId", appId).put("displayName", "Default Media Receiver")
                    .put("namespaces", JSONArray().put(JSONObject().put("name", NS_MEDIA)))
                    .put("sessionId", sid).put("statusText", "Ready To Cast").put("transportId", transportId)
            )
        }
        val st = JSONObject().put("applications", apps).put("isActiveInput", true)
            .put("volume", JSONObject().put("level", volGet() / 100.0).put("muted", false))
        return JSONObject().put("requestId", rid).put("type", "RECEIVER_STATUS").put("status", st).toString()
    }

    private fun broadcastReceiver(rid: Int) {
        val s = receiverStatus(rid)
        for (c in conns) try { c.send("receiver-0", "*", NS_RECV, s) } catch (e: Exception) { }
    }

    private fun receiver(c: Conn, m: CastProto.Msg) {
        val j = json(m)
        val rid = j.optInt("requestId", 0)
        when (j.optString("type")) {
            "GET_STATUS" -> c.send(m.dst, m.src, NS_RECV, receiverStatus(rid))
            "GET_APP_AVAILABILITY" -> {
                val ids = j.optJSONArray("appId")
                val av = JSONObject()
                if (ids != null) for (i in 0 until ids.length()) av.put(ids.getString(i), "APP_AVAILABLE")
                c.send(
                    m.dst, m.src, NS_RECV,
                    JSONObject().put("requestId", rid).put("responseType", "GET_APP_AVAILABILITY")
                        .put("availability", av).toString()
                )
            }
            "LAUNCH" -> {
                appId = j.optString("appId", "CC1AD845")
                sessionId = UUID.randomUUID().toString()
                transportId = "web-" + (System.nanoTime() % 100000)
                broadcastReceiver(rid)
            }
            "STOP" -> {
                sessionId = null
                Renderer.stop()
                broadcastReceiver(rid)
            }
            "SET_VOLUME" -> {
                val v = j.optJSONObject("volume")
                if (v != null && v.has("level")) volSet((v.optDouble("level", 1.0) * 100).toInt())
                broadcastReceiver(rid)
            }
        }
    }

    private fun mediaStatus(rid: Int): String {
        val ps = when (Renderer.state) {
            "PLAYING" -> "PLAYING"
            "PAUSED_PLAYBACK" -> "PAUSED"
            "TRANSITIONING" -> "BUFFERING"
            else -> "IDLE"
        }
        val arr = JSONArray()
        if (Renderer.uri.isNotEmpty() && sessionId != null) {
            val media = JSONObject().put("contentId", Renderer.uri).put("streamType", "BUFFERED").put("contentType", contentType)
            if (Renderer.durMs > 0) media.put("duration", Renderer.durMs / 1000.0)
            val o = JSONObject().put("mediaSessionId", 1).put("playerState", ps)
                .put("currentTime", Renderer.posMs / 1000.0).put("supportedMediaCommands", 15)
                .put("playbackRate", 1).put("currentItemId", 1).put("media", media)
                .put("volume", JSONObject().put("level", volGet() / 100.0).put("muted", false))
            if (ps == "IDLE") o.put("idleReason", "FINISHED")
            arr.put(o)
        }
        return JSONObject().put("requestId", rid).put("type", "MEDIA_STATUS").put("status", arr).toString()
    }

    private fun broadcastMedia(rid: Int) {
        val s = mediaStatus(rid)
        for (c in conns) try { c.send(transportId.ifEmpty { "receiver-0" }, "*", NS_MEDIA, s) } catch (e: Exception) { }
    }

    private fun media(c: Conn, m: CastProto.Msg) {
        val j = json(m)
        val rid = j.optInt("requestId", 0)
        when (j.optString("type")) {
            "GET_STATUS" -> { c.send(m.dst, m.src, NS_MEDIA, mediaStatus(rid)); return }
            "LOAD" -> {
                val media = j.optJSONObject("media") ?: return
                val url = media.optString("contentId")
                if (url.isEmpty()) return
                contentType = media.optString("contentType", "video/mp4")
                var sub: String? = null
                val tracks = media.optJSONArray("tracks")
                if (tracks != null) {
                    for (i in 0 until tracks.length()) {
                        val t = tracks.optJSONObject(i) ?: continue
                        val u = t.optString("trackContentId")
                        if (t.optString("type") == "TEXT" && u.isNotEmpty()) { sub = u; break }
                    }
                }
                Renderer.setUri(url, "")
                if (sub != null) Renderer.subUrl = sub
                Renderer.startMs = (j.optDouble("currentTime", 0.0) * 1000).toLong()
                if (j.optBoolean("autoplay", true)) Renderer.play(ctx)
            }
            "PLAY" -> Renderer.play(ctx)
            "PAUSE" -> Renderer.pause()
            "SEEK" -> Renderer.seek((j.optDouble("currentTime", 0.0) * 1000).toLong())
            "STOP" -> Renderer.stop()
        }
        broadcastMedia(rid)
    }
}
