package com.rakki.boxdlna

object CueParser {
    class C(val s: Long, val e: Long, val t: String)

    private val TIME = Regex("""((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})\s*-->\s*((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})""")
    private val TAG = Regex("<[^>]*>")
    private val BRACE = Regex("\\{[^}]*\\}")

    fun parse(text: String): List<C> = try {
        val out = if (text.contains("[Script Info]") || text.contains("\nDialogue:")) parseAss(text) else parseSrtVtt(text)
        out.sortedBy { it.s }
    } catch (e: Exception) { emptyList() }

    private fun clean(s: String): String =
        s.replace(TAG, "").replace(BRACE, "")
            .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
            .lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")

    private fun ts(s: String): Long {
        val p = s.replace(',', '.').split(':')
        val sec = p.last()
        val whole = sec.substringBefore('.').toLong()
        val frac = sec.substringAfter('.', "").padEnd(3, '0').take(3).toLong()
        val min = if (p.size >= 2) p[p.size - 2].toLong() else 0L
        val hr = if (p.size >= 3) p[p.size - 3].toLong() else 0L
        return ((hr * 60 + min) * 60 + whole) * 1000 + frac
    }

    private fun parseSrtVtt(text: String): List<C> {
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = ArrayList<C>()
        var i = 0
        while (i < lines.size) {
            val m = TIME.find(lines[i])
            if (m != null) {
                val start = ts(m.groupValues[1])
                val end = ts(m.groupValues[2])
                val sb = StringBuilder()
                i++
                while (i < lines.size && lines[i].isNotBlank()) { sb.append(lines[i]).append('\n'); i++ }
                val txt = clean(sb.toString())
                if (txt.isNotEmpty()) out.add(C(start, end, txt))
            } else i++
        }
        return out
    }

    private fun parseAss(text: String): List<C> {
        var fmt = listOf("layer", "start", "end", "style", "name", "marginl", "marginr", "marginv", "effect", "text")
        var inEvents = false
        val out = ArrayList<C>()
        for (raw in text.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            val ln = raw.trim()
            if (ln.startsWith("[")) { inEvents = ln.equals("[Events]", true); continue }
            if (!inEvents) continue
            if (ln.startsWith("Format:")) {
                fmt = ln.substringAfter(':').split(',').map { it.trim().lowercase() }
            } else if (ln.startsWith("Dialogue:")) {
                val parts = ln.substringAfter(':').trimStart().split(',', limit = fmt.size)
                val si = fmt.indexOf("start"); val ei = fmt.indexOf("end"); val ti = fmt.indexOf("text")
                if (si < 0 || ei < 0 || ti < 0 || parts.size <= ti) continue
                val txt = clean(parts[ti].replace("\\N", "\n").replace("\\n", "\n"))
                if (txt.isNotEmpty()) out.add(C(ts(parts[si].trim()), ts(parts[ei].trim()), txt))
            }
        }
        return out
    }
}
