package com.rakki.boxdlna

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLDecoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class DlnaService : Service() {

    companion object {
        @Volatile var httpPort = 0
        private const val CHANNEL = "dlna"
        private const val SERVER = "Android UPnP/1.0 BoxDlna/1.0"
        private const val XML = "text/xml; charset=\"utf-8\""
        private const val TXT = "text/plain; charset=utf-8"
        private val NONE = emptyList<Pair<String, String>>()

        fun getUdn(ctx: Context): String {
            val p = ctx.getSharedPreferences("box", Context.MODE_PRIVATE)
            var u = p.getString("udn", null)
            if (u == null) {
                u = UUID.randomUUID().toString()
                p.edit().putString("udn", u).apply()
            }
            return u
        }

        fun name(ctx: Context): String =
            ctx.getSharedPreferences("box", Context.MODE_PRIVATE).getString("name", null) ?: "Box DLNA"

    }

    private class Req(val method: String, val path: String, val headers: Map<String, String>, val body: ByteArray)
    private class Sub(val callback: String, var seq: Int = 0)

    private val pool = Executors.newCachedThreadPool()
    @Volatile private var alive = false
    private var server: ServerSocket? = null
    private var mcast: MulticastSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private var udn = ""
    private val avtSubs = ConcurrentHashMap<String, Sub>()
    private var cast: CastServer? = null
    private val am by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotif())
        if (!alive) startAll()
        return START_STICKY
    }

    override fun onDestroy() {
        byebye()
        alive = false
        Renderer.onChange = null
        try { cast?.stop() } catch (e: Exception) { }
        try { server?.close() } catch (e: Exception) { }
        try { mcast?.close() } catch (e: Exception) { }
        try { lock?.release() } catch (e: Exception) { }
        pool.shutdown()
        super.onDestroy()
    }

    private fun volGet(): Int {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    private fun volSet(v: Int) {
        try {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v.coerceIn(0, 100) * max / 100, 0)
        } catch (e: Exception) { }
    }

    private fun buildNotif(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "DLNA", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setContentTitle("Box DLNA").setContentText("جاهز لاستقبال البث")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
    }

    private fun startAll() {
        alive = true
        udn = getUdn(this)
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wm.createMulticastLock("boxdlna").apply { setReferenceCounted(false); acquire() }
        } catch (e: Exception) { }
        Renderer.onChange = { pool.execute { sendEvents(); cast?.onStateChanged() } }
        val castOff = getSharedPreferences("box", Context.MODE_PRIVATE).getBoolean("castOff", false)
        CastDiag.tls = if (castOff) "Chromecast: متوقف" else "TLS: جارٍ البدء…"
        if (!castOff) {
            cast = CastServer(this, udn, { volGet() }, { volSet(it) })
            pool.execute {
                try {
                    cast?.start("Box Chrome")
                } catch (e: Throwable) {
                    CastDiag.tls = "TLS: فشل — " + e.javaClass.simpleName + ": " + (e.message ?: "").take(70)
                    try {
                        java.io.File(filesDir, "crash.txt").writeText("cast start\n" + android.util.Log.getStackTraceString(e))
                        getSharedPreferences("box", Context.MODE_PRIVATE).edit().putBoolean("castOff", true).commit()
                    } catch (x: Throwable) { }
                }
            }
        }
        pool.execute { try { runHttp() } catch (e: Exception) { } }
        pool.execute { runSsdp() }
    }

    // ---------------------------------------------------------------- HTTP

    private fun runHttp() {
        val s = ServerSocket()
        s.reuseAddress = true
        try { s.bind(InetSocketAddress(49152)) } catch (e: Exception) { s.bind(InetSocketAddress(0)) }
        server = s
        httpPort = s.localPort
        while (alive) {
            val c = try { s.accept() } catch (e: Exception) { break }
            pool.execute {
                try { handle(c) } catch (e: Exception) { } finally { try { c.close() } catch (e: Exception) { } }
            }
        }
    }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == 10) break
            if (b != 13) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun readN(i: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var o = 0
        while (o < n) {
            val r = i.read(buf, o, n - o)
            if (r < 0) break
            o += r
        }
        return buf.copyOf(o)
    }

    private fun readReq(i: InputStream): Req? {
        val first = readLine(i) ?: return null
        val parts = first.split(" ")
        if (parts.size < 2) return null
        val h = HashMap<String, String>()
        while (true) {
            val ln = readLine(i) ?: break
            if (ln.isEmpty()) break
            val k = ln.indexOf(':')
            if (k > 0) h[ln.substring(0, k).trim().lowercase()] = ln.substring(k + 1).trim()
        }
        val te = h["transfer-encoding"]
        val body: ByteArray
        if (te != null && te.contains("chunked", true)) {
            val bo = ByteArrayOutputStream()
            while (true) {
                val ln = readLine(i) ?: break
                val sz = ln.trim().substringBefore(';').toIntOrNull(16) ?: break
                if (sz == 0) { readLine(i); break }
                bo.write(readN(i, sz))
                readLine(i)
                if (bo.size() > 6_000_000) return null
            }
            body = bo.toByteArray()
        } else {
            val n = h["content-length"]?.toIntOrNull() ?: 0
            if (n > 6_000_000) return null
            body = readN(i, n)
        }
        return Req(parts[0].uppercase(), parts[1], h, body)
    }

    private fun send(o: OutputStream, code: Int, type: String?, body: ByteArray, extra: String = "") {
        val h = StringBuilder("HTTP/1.1 $code ${if (code == 200) "OK" else "Error"}\r\n")
        if (type != null) h.append("Content-Type: $type\r\n")
        h.append("Content-Length: ${body.size}\r\nConnection: close\r\nServer: $SERVER\r\n$extra\r\n")
        o.write(h.toString().toByteArray())
        o.write(body)
        o.flush()
    }

    private fun handle(c: Socket) {
        c.soTimeout = 15000
        val i = BufferedInputStream(c.getInputStream())
        val o = c.getOutputStream()
        val r = readReq(i) ?: return
        val p = r.path.substringBefore('?')
        val svc = p.split('/').getOrElse(1) { "" }
        when {
            r.method == "GET" && p == "/" -> send(o, 200, "text/html; charset=utf-8", page())
            r.method == "GET" && p == "/desc.xml" -> send(o, 200, XML, desc().toByteArray())
            r.method == "GET" && p.endsWith("/scpd.xml") -> {
                val x = when (p) {
                    "/avt/scpd.xml" -> Upnp.avtScpd
                    "/rc/scpd.xml" -> Upnp.rcScpd
                    "/cm/scpd.xml" -> Upnp.cmScpd
                    else -> null
                }
                if (x == null) send(o, 404, TXT, "Not found".toByteArray()) else send(o, 200, XML, x.toByteArray())
            }
            r.method == "POST" && p.endsWith("/control") -> soap(svc, r, o)
            r.method == "SUBSCRIBE" -> subscribe(svc, r, o)
            r.method == "UNSUBSCRIBE" -> {
                r.headers["sid"]?.let { avtSubs.remove(it) }
                send(o, 200, null, ByteArray(0))
            }
            r.method == "POST" && p == "/subtitle" -> uploadSub(r, o)
            r.method == "GET" && p == "/style" -> send(o, 200, "application/json", SubStyle.json(this).toByteArray())
            r.method == "GET" && p == "/set" -> setStyle(r.path, o)
            r.method == "GET" && p.startsWith("/sub/") || r.method == "GET" && p == "/status" || r.method == "GET" && p == "/apikey" || r.method == "GET" && p == "/log" -> control(p, r.path, o)
            else -> send(o, 404, TXT, "Not found".toByteArray())
        }
    }

    // ---------------------------------------------------------------- phone / sender control API (HTTP, JSON)

    private fun query(path: String): Map<String, String> {
        val q = HashMap<String, String>()
        for (kv in path.substringAfter('?', "").split('&')) {
            val k = kv.substringBefore('=', "")
            if (k.isNotEmpty()) q[k] = URLDecoder.decode(kv.substringAfter('=', ""), "UTF-8")
        }
        return q
    }

    private fun json(o: OutputStream, j: org.json.JSONObject) =
        send(o, 200, "application/json; charset=utf-8", j.toString().toByteArray(Charsets.UTF_8))

    private fun statusJson(): org.json.JSONObject {
        val q = SubSearch.current()
        val src = when {
            Renderer.effectiveManual() != null -> "manual"
            Renderer.subUrl != null -> "sender"
            else -> "none"
        }
        return org.json.JSONObject()
            .put("state", Renderer.state)
            .put("posMs", Renderer.posMs)
            .put("durMs", Renderer.durMs)
            .put("title", q?.title ?: "")
            .put("year", q?.year ?: "")
            .put("season", q?.season ?: 0)
            .put("episode", q?.episode ?: 0)
            .put("subs", Renderer.cueCount > 0)
            .put("subsEnabled", Renderer.subsEnabled)
            .put("subSource", src)
            .put("offsetMs", Renderer.subOffsetMs)
            .put("hasApiKey", Cfg.apiKey(this).isNotEmpty())
    }

    /**
     * GET /status
     * GET /sub/offset?ms=1200 | ?delta=-500      subtitle delay, applied live (video keeps playing)
     * GET /sub/enable?v=0|1
     * GET /sub/search?src=online|box&lang=ara|fre|eng   -> numbered results
     * GET /sub/apply?i=N                         download + apply result N, live
     * GET /sub/autosync                          audio-based auto sync
     * GET /apikey?key=..&user=..&pass=..         store OpenSubtitles credentials
     */
    private fun control(p: String, path: String, o: OutputStream) {
        val q = query(path)
        when (p) {
            "/status" -> json(o, statusJson())
            "/log" -> send(o, 200, TXT, CmdLog.dump(80).toByteArray(Charsets.UTF_8))
            "/apikey" -> {
                if (q.containsKey("key")) Cfg.save(this, q["key"] ?: "", q["user"] ?: "", q["pass"] ?: "")
                json(o, org.json.JSONObject().put("hasApiKey", Cfg.apiKey(this).isNotEmpty()).put("user", Cfg.user(this)))
            }
            "/sub/offset" -> {
                val abs = q["ms"]?.toLongOrNull()
                val delta = q["delta"]?.toLongOrNull()
                if (abs != null) Renderer.subOffsetMs = abs.coerceIn(-600_000L, 600_000L)
                else if (delta != null) Renderer.subOffsetMs = (Renderer.subOffsetMs + delta).coerceIn(-600_000L, 600_000L)
                json(o, statusJson())
            }
            "/sub/enable" -> {
                Renderer.subsEnabled = q["v"] != "0"
                json(o, statusJson())
            }
            "/sub/autosync" -> {
                Renderer.main.post { Renderer.activity?.autoSync() }
                json(o, statusJson())
            }
            "/sub/search" -> {
                val online = q["src"] != "box"
                val lang = SubSearch.langIds.indexOf(q["lang"] ?: "ara").coerceAtLeast(0)
                val sq = SubSearch.current()
                val arr = org.json.JSONArray()
                var err = ""
                try {
                    val res = if (online) {
                        if (sq == null) emptyList() else SubSearch.searchOnline(this, sq, lang)
                    } else SubSearch.searchLocal(this, sq)
                    Renderer.results = res
                    for ((i, r) in res.withIndex())
                        arr.put(org.json.JSONObject().put("i", i).put("name", r.label).put("info", r.info).put("exact", r.exact))
                } catch (e: Exception) { err = e.message ?: "error" }
                json(o, org.json.JSONObject().put("query", sq?.display() ?: "").put("results", arr).put("error", err))
            }
            "/sub/apply" -> {
                val r = Renderer.results.getOrNull(q["i"]?.toIntOrNull() ?: -1)
                var ok = false
                if (r != null) {
                    try {
                        val f = r.file
                        val s = if (f != null) SubtitleLoader.normalize(f.readBytes(), cacheDir, "manual") else SubSearch.download(this, r, cacheDir)
                        if (s != null) { Renderer.applyManual(s, r.label); ok = true }
                    } catch (e: Exception) { }
                }
                json(o, org.json.JSONObject().put("ok", ok))
            }
            else -> send(o, 404, TXT, "Not found".toByteArray())
        }
    }

    private fun page(): ByteArray = assets.open("index.html").use { it.readBytes() }

    private fun setStyle(path: String, o: OutputStream) {
        val q = HashMap<String, String>()
        for (kv in path.substringAfter('?', "").split('&')) {
            val k = kv.substringBefore('=', "")
            if (k.isNotEmpty()) q[k] = URLDecoder.decode(kv.substringAfter('=', ""), "UTF-8")
        }
        if (q["reset"] == "1") {
            SubStyle.reset(this)
        } else {
            val cur = SubStyle.get(this)
            val color = q["color"]?.let { try { Color.parseColor("#" + it) } catch (e: Exception) { null } } ?: cur.color
            val bg = q["bg"]?.let { try { Color.parseColor("#" + it) } catch (e: Exception) { null } } ?: cur.bg
            SubStyle.save(
                this,
                q["size"]?.toFloatOrNull()?.coerceIn(10f, 80f) ?: cur.size,
                color, bg,
                q["opacity"]?.toIntOrNull()?.coerceIn(0, 100) ?: cur.opacity,
                q["pos"]?.toIntOrNull()?.coerceIn(0, 60) ?: cur.pos,
                q["edge"]?.let { it == "1" } ?: cur.edge
            )
        }
        Renderer.main.post { Renderer.activity?.applyStyle() }
        send(o, 200, TXT, "ok".toByteArray())
    }

    private fun uploadSub(r: Req, o: OutputStream) {
        val s = SubtitleLoader.normalize(r.body, cacheDir, "manual")
        if (s == null) {
            send(o, 200, TXT, "فشل: ملف غير صالح".toByteArray())
            return
        }
        Renderer.applyManual(s, "Phone")
        send(o, 200, TXT, "تم ✓ الترجمة جاهزة".toByteArray())
    }

    private fun desc(): String {
        fun svc(type: String, id: String, k: String) =
            "<service><serviceType>$type</serviceType><serviceId>urn:upnp-org:serviceId:$id</serviceId>" +
                "<SCPDURL>/$k/scpd.xml</SCPDURL><controlURL>/$k/control</controlURL><eventSubURL>/$k/event</eventSubURL></service>"
        return "<?xml version=\"1.0\"?><root xmlns=\"urn:schemas-upnp-org:device-1-0\" xmlns:dlna=\"urn:schemas-dlna-org:device-1-0\">" +
            "<specVersion><major>1</major><minor>0</minor></specVersion><device>" +
            "<dlna:X_DLNADOC>DMR-1.50</dlna:X_DLNADOC>" +
            "<deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType>" +
            "<friendlyName>${esc(name(this))}</friendlyName><manufacturer>BoxDlna</manufacturer>" +
            "<modelName>BoxDlna Renderer</modelName><modelNumber>1</modelNumber><UDN>uuid:$udn</UDN>" +
            "<serviceList>" + svc(Upnp.AVT, "AVTransport", "avt") + svc(Upnp.RC, "RenderingControl", "rc") +
            svc(Upnp.CM, "ConnectionManager", "cm") + "</serviceList></device></root>"
    }

    // ---------------------------------------------------------------- SOAP

    private fun serviceType(k: String) = when (k) { "avt" -> Upnp.AVT; "rc" -> Upnp.RC; else -> Upnp.CM }

    private fun soap(svc: String, r: Req, o: OutputStream) {
        val action = (r.headers["soapaction"] ?: "").trim().trim('"').substringAfter('#')
        val body = String(r.body, Charsets.UTF_8)
        val args = Regex("<([A-Za-z_][\\w.-]*)>([^<]*)</\\1>").findAll(body)
            .associate { it.groupValues[1] to unesc(it.groupValues[2]) }
        val res: List<Pair<String, String>>? = try {
            when (svc) { "avt" -> avt(action, args); "rc" -> rc(action, args); else -> cm(action, args) }
        } catch (e: Exception) { null }
        if (res == null) {
            val f = "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><s:Fault><faultcode>s:Client</faultcode><faultstring>UPnPError</faultstring><detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\"><errorCode>401</errorCode><errorDescription>Invalid Action</errorDescription></UPnPError></detail></s:Fault></s:Body></s:Envelope>"
            send(o, 500, XML, f.toByteArray())
            return
        }
        val sb = StringBuilder("<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>")
        sb.append("<u:${action}Response xmlns:u=\"${serviceType(svc)}\">")
        for ((k, v) in res) sb.append("<$k>${esc(v)}</$k>")
        sb.append("</u:${action}Response></s:Body></s:Envelope>")
        send(o, 200, XML, sb.toString().toByteArray())
    }

    private fun avt(a: String, p: Map<String, String>): List<Pair<String, String>>? {
        val dur = hms(Renderer.durMs)
        val pos = hms(Renderer.posMs)
        val has = Renderer.uri.isNotEmpty()
        return when (a) {
            "SetAVTransportURI" -> { Renderer.setUri(p["CurrentURI"] ?: "", p["CurrentURIMetaData"] ?: ""); NONE }
            "SetNextAVTransportURI", "Next", "Previous", "SetPlayMode" -> NONE
            "Play" -> { CmdLog.add("Play"); Renderer.play(this); NONE }
            "Pause" -> { CmdLog.add("Pause"); Renderer.pause(); NONE }
            "Stop" -> {
                if (Renderer.ignoreStop && Renderer.activity != null) CmdLog.add("Stop (ignored)")
                else { CmdLog.add("Stop (in 1.5 s, unless the video is re-sent)"); Renderer.stopSoon() }
                NONE
            }
            "Seek" -> {
                val t = parseTime(p["Target"] ?: "")
                val u = p["Unit"]
                CmdLog.add("Seek " + (p["Target"] ?: "") + " " + (u ?: ""))
                if (t != null && (u == "REL_TIME" || u == "ABS_TIME")) Renderer.seek(t)
                NONE
            }
            "GetTransportInfo" -> listOf("CurrentTransportState" to Renderer.state, "CurrentTransportStatus" to "OK", "CurrentSpeed" to "1")
            "GetPositionInfo" -> listOf(
                "Track" to (if (has) "1" else "0"), "TrackDuration" to dur, "TrackMetaData" to Renderer.meta,
                "TrackURI" to Renderer.uri, "RelTime" to pos, "AbsTime" to pos,
                "RelCount" to "2147483647", "AbsCount" to "2147483647"
            )
            "GetMediaInfo" -> listOf(
                "NrTracks" to (if (has) "1" else "0"), "MediaDuration" to dur,
                "CurrentURI" to Renderer.uri, "CurrentURIMetaData" to Renderer.meta,
                "NextURI" to "NOT_IMPLEMENTED", "NextURIMetaData" to "NOT_IMPLEMENTED",
                "PlayMedium" to "NETWORK", "RecordMedium" to "NOT_IMPLEMENTED", "WriteStatus" to "NOT_IMPLEMENTED"
            )
            "GetDeviceCapabilities" -> listOf("PlayMedia" to "NETWORK", "RecMedia" to "NOT_IMPLEMENTED", "RecQualityModes" to "NOT_IMPLEMENTED")
            "GetTransportSettings" -> listOf("PlayMode" to "NORMAL", "RecQualityMode" to "NOT_IMPLEMENTED")
            "GetCurrentTransportActions" -> listOf("Actions" to "Play,Pause,Stop,Seek")
            else -> null
        }
    }

    private fun rc(a: String, p: Map<String, String>): List<Pair<String, String>>? {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return when (a) {
            "ListPresets" -> listOf("CurrentPresetNameList" to "FactoryDefaults")
            "SelectPreset" -> NONE
            "GetVolume" -> listOf("CurrentVolume" to (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max).toString())
            "SetVolume" -> {
                val v = (p["DesiredVolume"]?.toIntOrNull() ?: 0).coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v * max / 100, 0)
                NONE
            }
            "GetMute" -> listOf("CurrentMute" to (if (am.isStreamMute(AudioManager.STREAM_MUSIC)) "1" else "0"))
            "SetMute" -> {
                val m = p["DesiredMute"] == "1" || p["DesiredMute"].equals("true", true)
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (m) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
                NONE
            }
            else -> null
        }
    }

    private fun cm(a: String, p: Map<String, String>): List<Pair<String, String>>? = when (a) {
        "GetProtocolInfo" -> listOf(
            "Source" to "",
            "Sink" to "http-get:*:video/mp4:*,http-get:*:video/x-matroska:*,http-get:*:video/avi:*,http-get:*:video/x-msvideo:*," +
                "http-get:*:video/mpeg:*,http-get:*:video/quicktime:*,http-get:*:video/webm:*,http-get:*:video/x-flv:*," +
                "http-get:*:video/3gpp:*,http-get:*:audio/mpeg:*,http-get:*:audio/mp4:*,http-get:*:audio/flac:*," +
                "http-get:*:application/vnd.apple.mpegurl:*"
        )
        "GetCurrentConnectionIDs" -> listOf("ConnectionIDs" to "0")
        "GetCurrentConnectionInfo" -> listOf(
            "RcsID" to "0", "AVTransportID" to "0", "ProtocolInfo" to "", "PeerConnectionManager" to "",
            "PeerConnectionID" to "-1", "Direction" to "Input", "Status" to "OK"
        )
        else -> null
    }

    // ---------------------------------------------------------------- Events

    private fun subscribe(svc: String, r: Req, o: OutputStream) {
        val existing = r.headers["sid"]
        val cb = r.headers["callback"]?.let { Regex("<([^>]+)>").find(it)?.groupValues?.get(1) }
        val sid: String
        if (existing == null) {
            if (cb == null) { send(o, 412, null, ByteArray(0)); return }
            sid = "uuid:" + UUID.randomUUID()
            if (svc == "avt") avtSubs[sid] = Sub(cb)
        } else sid = existing
        send(o, 200, null, ByteArray(0), "SID: $sid\r\nTIMEOUT: Second-1800\r\n")
        if (svc == "avt" && existing == null) pool.execute { Thread.sleep(300); sendEvents() }
    }

    private fun avtEvent(): String {
        val inner = "<Event xmlns=\"urn:schemas-upnp-org:metadata-1-0/AVT/\"><InstanceID val=\"0\">" +
            "<TransportState val=\"${Renderer.state}\"/><TransportStatus val=\"OK\"/>" +
            "<AVTransportURI val=\"${esc(Renderer.uri)}\"/><AVTransportURIMetaData val=\"${esc(Renderer.meta)}\"/>" +
            "<CurrentTransportActions val=\"Play,Pause,Stop,Seek\"/></InstanceID></Event>"
        return "<?xml version=\"1.0\"?><e:propertyset xmlns:e=\"urn:schemas-upnp-org:event-1-0\"><e:property><LastChange>" +
            esc(inner) + "</LastChange></e:property></e:propertyset>"
    }

    private fun sendEvents() {
        if (avtSubs.isEmpty()) return
        val body = avtEvent()
        for ((sid, sub) in avtSubs) notifyOne(sid, sub, body)
    }

    private fun notifyOne(sid: String, sub: Sub, body: String) {
        try {
            val u = URL(sub.callback)
            val port = if (u.port > 0) u.port else 80
            Socket().use { s ->
                s.connect(InetSocketAddress(u.host, port), 3000)
                s.soTimeout = 3000
                val b = body.toByteArray()
                val seq = sub.seq++
                val h = "NOTIFY ${u.file} HTTP/1.1\r\nHOST: ${u.host}:$port\r\nCONTENT-TYPE: text/xml; charset=\"utf-8\"\r\n" +
                    "NT: upnp:event\r\nNTS: upnp:propchange\r\nSID: $sid\r\nSEQ: $seq\r\nCONTENT-LENGTH: ${b.size}\r\nCONNECTION: close\r\n\r\n"
                val os = s.getOutputStream()
                os.write(h.toByteArray())
                os.write(b)
                os.flush()
                s.getInputStream().read()
            }
        } catch (e: Exception) { avtSubs.remove(sid) }
    }

    // ---------------------------------------------------------------- SSDP

    private fun targets(): List<Pair<String, String>> {
        val u = "uuid:$udn"
        return listOf(
            "upnp:rootdevice" to "$u::upnp:rootdevice",
            u to u,
            "urn:schemas-upnp-org:device:MediaRenderer:1" to "$u::urn:schemas-upnp-org:device:MediaRenderer:1",
            Upnp.AVT to "$u::${Upnp.AVT}",
            Upnp.RC to "$u::${Upnp.RC}",
            Upnp.CM to "$u::${Upnp.CM}"
        )
    }

    private fun location(ip: String) = "http://$ip:$httpPort/desc.xml"

    private fun runSsdp() {
        val group = InetAddress.getByName("239.255.255.250")
        while (alive && httpPort == 0) Thread.sleep(100)
        while (alive) {
            val local = NetUtil.local()
            if (local == null) { Thread.sleep(3000); continue }
            try {
                val s = MulticastSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(1900))
                s.soTimeout = 1000
                s.networkInterface = local.second
                s.joinGroup(InetSocketAddress(group, 1900), local.second)
                mcast = s
                announce(s, group, local.first)
                Thread.sleep(250)
                announce(s, group, local.first)
                var last = System.currentTimeMillis()
                val buf = ByteArray(2048)
                while (alive && NetUtil.local()?.first == local.first) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        onSearch(s, p, local.first)
                    } catch (e: SocketTimeoutException) { }
                    if (System.currentTimeMillis() - last > 20000) {
                        announce(s, group, local.first)
                        last = System.currentTimeMillis()
                    }
                }
                s.close()
            } catch (e: Exception) {
                Thread.sleep(2000)
            }
        }
    }

    private fun byebye() {
        val s = mcast ?: return
        try {
            val g = InetAddress.getByName("239.255.255.250")
            for ((nt, usn) in targets()) {
                val m = "NOTIFY * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nNT: $nt\r\nNTS: ssdp:byebye\r\nUSN: $usn\r\n\r\n"
                val b = m.toByteArray()
                s.send(DatagramPacket(b, b.size, g, 1900))
            }
        } catch (e: Exception) { }
    }

    private fun announce(s: MulticastSocket, g: InetAddress, ip: String) {
        for ((nt, usn) in targets()) {
            val m = "NOTIFY * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nCACHE-CONTROL: max-age=1800\r\n" +
                "LOCATION: ${location(ip)}\r\nNT: $nt\r\nNTS: ssdp:alive\r\nSERVER: $SERVER\r\nUSN: $usn\r\n\r\n"
            val b = m.toByteArray()
            try { s.send(DatagramPacket(b, b.size, g, 1900)) } catch (e: Exception) { }
        }
    }

    private fun onSearch(s: MulticastSocket, p: DatagramPacket, ip: String) {
        val txt = String(p.data, 0, p.length)
        if (!txt.startsWith("M-SEARCH")) return
        val h = HashMap<String, String>()
        for (ln in txt.lines().drop(1)) {
            val k = ln.indexOf(':')
            if (k > 0) h[ln.substring(0, k).trim().uppercase()] = ln.substring(k + 1).trim()
        }
        val st = h["ST"] ?: return
        val mx = (h["MX"]?.toIntOrNull() ?: 1).coerceIn(1, 5)
        val dest = p.address
        val port = p.port
        for ((nt, usn) in targets()) {
            if (st == "ssdp:all" || st == nt) {
                pool.execute {
                    try {
                        Thread.sleep((Math.random() * mx * 400).toLong())
                        val m = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\nLOCATION: ${location(ip)}\r\n" +
                            "SERVER: $SERVER\r\nST: $nt\r\nUSN: $usn\r\n\r\n"
                        val b = m.toByteArray()
                        s.send(DatagramPacket(b, b.size, dest, port))
                    } catch (e: Exception) { }
                }
            }
        }
    }
}
