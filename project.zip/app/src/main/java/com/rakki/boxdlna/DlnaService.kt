package com.rakki.boxdlna

import android.content.Context
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.MulticastSocket

class DlnaService(private val ctx: Context, private val udn: String) {
    private var active = false
    private var thread: Thread? = null

    fun start() {
        if (active) return
        active = true
        thread = Thread {
            try {
                val group = InetAddress.getByName("239.255.255.250")
                val socket = MulticastSocket(1900)
                socket.joinGroup(group)
                val buf = ByteArray(1024)
                while (active) {
                    val packet = DatagramPacket(buf, buf.size)
                    socket.receive(packet)
                    val req = String(packet.data, 0, packet.length)
                    if (req.contains("M-SEARCH")) {
                        val resp = "HTTP/1.1 200 OK\r\n" +
                                "CACHE-CONTROL: max-age=900\r\n" +
                                "EXT:\r\n" +
                                "LOCATION: http://" + socket.localAddress.hostAddress + ":8080/description.xml\r\n" +
                                "SERVER: Android/7.0 UPnP/1.0 BoxDLNA\r\n" +
                                "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n" +
                                "USN: uuid:$udn::urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n"
                        val data = resp.toByteArray()
                        val respPacket = DatagramPacket(data, data.size, packet.address, packet.port)
                        socket.send(respPacket)
                    }
                }
            } catch (e: Exception) {}
        }
        thread?.start()
    }

    fun stop() {
        active = false
        thread?.interrupt()
    }
}
