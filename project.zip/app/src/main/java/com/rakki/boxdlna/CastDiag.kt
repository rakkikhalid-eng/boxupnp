package com.rakki.boxdlna

import java.util.Collections

/** Live status of the Cast receiver, shown on the home screen to debug discovery. */
object CastDiag {
    @Volatile var tls = "لم يبدأ"
    @Volatile var mdns = "لم يبدأ"
    @Volatile var conns = 0
    @Volatile var last = "-"
    val found: MutableSet<String> = Collections.synchronizedSet(LinkedHashSet<String>())

    fun text(): String {
        val names = synchronized(found) { found.toList() }
        return tls + "\n" + mdns +
            "\nاتصالات من تطبيقات الإرسال: " + conns +
            "\nآخر رسالة وصلت: " + last +
            "\nأجهزة Cast ظاهرة على الشبكة: " + names.size +
            (if (names.isEmpty()) "" else "\n" + names.joinToString("، "))
    }
}
