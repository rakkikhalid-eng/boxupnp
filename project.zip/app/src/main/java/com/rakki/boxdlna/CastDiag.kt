package com.rakki.boxdlna

object CastDiag {
    var tls = "TLS: في الانتظار..."
    var mdns = "mDNS: في الانتظار..."
    var conns = 0
    var last = "لا شيء"
}
