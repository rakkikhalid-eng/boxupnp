package com.rakki.boxdlna

import android.content.Context
import android.graphics.Color
import java.util.Locale

object SubStyle {
    data class S(val size: Float, val color: Int, val bg: Int, val opacity: Int, val pos: Int, val edge: Boolean)

    private fun prefs(c: Context) = c.getSharedPreferences("style", Context.MODE_PRIVATE)

    fun get(c: Context): S {
        val p = prefs(c)
        return S(
            p.getFloat("size", 26f), p.getInt("color", Color.WHITE), p.getInt("bg", Color.BLACK),
            p.getInt("opacity", 0), p.getInt("pos", 8), p.getBoolean("edge", true)
        )
    }

    fun save(c: Context, size: Float, color: Int, bg: Int, opacity: Int, pos: Int, edge: Boolean) {
        prefs(c).edit().putFloat("size", size).putInt("color", color).putInt("bg", bg)
            .putInt("opacity", opacity).putInt("pos", pos).putBoolean("edge", edge).apply()
    }

    fun reset(c: Context) {
        val a = aspect(c)
        prefs(c).edit().clear().putInt("aspect", a).apply()
    }

    fun aspect(c: Context): Int = prefs(c).getInt("aspect", 0)
    fun setAspect(c: Context, v: Int) { prefs(c).edit().putInt("aspect", v).apply() }

    fun bgArgb(s: S): Int = ((s.opacity * 255 / 100) shl 24) or (s.bg and 0xFFFFFF)

    private fun hex(c: Int) = String.format(Locale.US, "#%06x", c and 0xFFFFFF)

    fun json(c: Context): String {
        val s = get(c)
        return "{\"size\":${s.size},\"color\":\"${hex(s.color)}\",\"bg\":\"${hex(s.bg)}\"," +
            "\"opacity\":${s.opacity},\"pos\":${s.pos},\"edge\":${s.edge}}"
    }
}
