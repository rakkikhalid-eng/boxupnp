package com.rakki.boxdlna

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Side "Options" panel: a root list with arrows to tabbed sub-pages (like the reference screenshot). */
class MenuPanel(private val ctx: Context, parent: FrameLayout, private val onClose: () -> Unit) {

    /** act(dir): -1 / +1 = left/right value change, 0 = OK / tap. */
    class Item(
        val icon: String,
        val label: () -> String,
        val value: (() -> String)? = null,
        val arrow: Boolean = false,
        val act: (Int) -> Unit
    )

    class Page(val tag: String, val title: () -> String, val items: () -> List<Item>, val onShow: (() -> Unit)? = null)

    private val dp = ctx.resources.displayMetrics.density
    private fun d(v: Int) = (v * dp).toInt()

    private val stack = ArrayList<Page>()
    private val sels = ArrayList<Int>()
    private var rows = ArrayList<View>()
    private var current: List<Item> = emptyList()

    private val box = LinearLayout(ctx)
    private val titleTv = TextView(ctx)
    private val closeTv = TextView(ctx)
    private val list = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)

    val isOpen: Boolean get() = box.visibility == View.VISIBLE
    val left: Int get() = box.left
    val tag: String get() = stack.lastOrNull()?.tag ?: ""

    companion object {
        val ACCENT = Color.parseColor("#3B82F6")
        val CARD = Color.parseColor("#2A2D3A")
        val CARD_LINE = Color.parseColor("#3C4150")
        val PANEL = Color.parseColor("#F2171A22")
    }

    init {
        box.orientation = LinearLayout.VERTICAL
        box.visibility = View.GONE
        val bg = GradientDrawable()
        bg.setColor(PANEL)
        bg.cornerRadius = d(26).toFloat()
        box.background = bg
        box.setPadding(d(16), d(14), d(16), d(14))
        box.isClickable = true

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        titleTv.textSize = 26f
        titleTv.setTypeface(titleTv.typeface, Typeface.BOLD)
        titleTv.setTextColor(Color.WHITE)
        titleTv.setPadding(d(6), 0, d(6), 0)
        titleTv.setOnClickListener { back() }
        closeTv.text = "✕"
        closeTv.textSize = 24f
        closeTv.setTextColor(Color.WHITE)
        closeTv.gravity = Gravity.CENTER
        closeTv.setOnClickListener { close() }
        head.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(closeTv, LinearLayout.LayoutParams(d(44), d(44)))
        box.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        list.orientation = LinearLayout.VERTICAL
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(list)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        slp.topMargin = d(8)
        box.addView(scroll, slp)

        val sw = ctx.resources.displayMetrics.widthPixels
        val w = minOf(d(440), (sw * 0.55f).toInt())
        val lp = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        lp.setMargins(d(8), d(10), d(10), d(10))
        parent.addView(box, lp)
    }

    fun open(root: Page) {
        stack.clear(); sels.clear()
        push(root)
        box.visibility = View.VISIBLE
    }

    fun push(p: Page) {
        stack.add(p); sels.add(0)
        p.onShow?.invoke()
        render()
    }

    fun back() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            sels.removeAt(sels.size - 1)
            render()
        } else close()
    }

    fun close() {
        if (!isOpen) return
        box.visibility = View.GONE
        stack.clear(); sels.clear()
        onClose()
    }

    fun render() {
        val page = stack.lastOrNull() ?: return
        box.layoutDirection = if (L.rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        titleTv.text = (if (stack.size > 1) (if (L.rtl) "› " else "‹ ") else "") + page.title()
        current = page.items()
        var sel = sels[sels.size - 1]
        if (sel >= current.size) sel = maxOf(0, current.size - 1)
        sels[sels.size - 1] = sel
        list.removeAllViews()
        rows = ArrayList()
        for ((i, item) in current.withIndex()) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(d(14), d(12), d(14), d(12))
            val g = GradientDrawable()
            g.cornerRadius = d(18).toFloat()
            if (i == sel) { g.setColor(ACCENT); g.setStroke(d(2), Color.WHITE) }
            else { g.setColor(CARD); g.setStroke(d(1), CARD_LINE) }
            row.background = g

            val ic = TextView(ctx)
            ic.text = item.icon
            ic.textSize = 20f
            ic.gravity = Gravity.CENTER
            ic.setTextColor(Color.WHITE)
            row.addView(ic, LinearLayout.LayoutParams(d(38), ViewGroup.LayoutParams.WRAP_CONTENT))

            val lb = TextView(ctx)
            lb.text = item.label()
            lb.textSize = 17f
            lb.setTextColor(Color.WHITE)
            lb.setPadding(d(8), 0, d(8), 0)
            row.addView(lb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val v = item.value?.invoke() ?: ""
            if (v.isNotEmpty()) {
                val vt = TextView(ctx)
                vt.text = v
                vt.textSize = 15f
                vt.setTextColor(if (i == sel) Color.WHITE else Color.parseColor("#AEB8CC"))
                vt.maxLines = 2
                row.addView(vt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            if (item.arrow) {
                val ar = TextView(ctx)
                ar.text = if (L.rtl) "‹" else "›"
                ar.textSize = 28f
                ar.setTextColor(Color.parseColor("#AEB8CC"))
                ar.setPadding(d(8), 0, d(2), 0)
                row.addView(ar)
            }
            row.isClickable = true
            row.setOnClickListener { sels[sels.size - 1] = i; item.act(0); if (isOpen) render() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = d(8)
            list.addView(row, lp)
            rows.add(row)
        }
        val s = sel
        scroll.post {
            val r = rows.getOrNull(s) ?: return@post
            scroll.smoothScrollTo(0, maxOf(0, r.top - scroll.height / 2 + r.height / 2))
        }
    }

    /** Returns true when the key was consumed. */
    fun key(k: Int): Boolean {
        if (stack.isEmpty()) return false
        val n = current.size
        var sel = sels[sels.size - 1]
        val fwd = if (L.rtl) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        val bwd = if (L.rtl) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP -> if (n > 0) { sels[sels.size - 1] = (sel - 1 + n) % n; render() }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (n > 0) { sels[sels.size - 1] = (sel + 1) % n; render() }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                current.getOrNull(sel)?.act?.invoke(0); if (isOpen) render()
            }
            fwd -> {
                val it = current.getOrNull(sel)
                if (it != null) { if (it.arrow) it.act(0) else it.act(1) }
                if (isOpen) render()
            }
            bwd -> {
                val it = current.getOrNull(sel)
                if (it != null && !it.arrow) { it.act(-1); render() }
                else if (stack.size > 1) back()
            }
            KeyEvent.KEYCODE_MENU -> close()
            KeyEvent.KEYCODE_BACK -> back()
            else -> return false
        }
        return true
    }
}
