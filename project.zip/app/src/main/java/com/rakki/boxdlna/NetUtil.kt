package com.rakki.boxdlna

import android.content.Context
import java.net.NetworkInterface
import java.util.Collections

object NetUtil {
    fun getMacAddress(ctx: Context): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (nif in interfaces) {
                if (nif.name.equals("wlan0", ignoreCase = true) || nif.name.equals("eth0", ignoreCase = true)) {
                    val macBytes = nif.hardwareAddress ?: continue
                    val res = StringBuilder()
                    for (b in macBytes) {
                        res.append(String.format("%02X:", b))
                    }
                    if (res.isNotEmpty()) {
                        res.deleteCharAt(res.length - 1)
                        return res.toString().replace(":", "-")
                    }
                }
            }
        } catch (e: Exception) {}
        return "12345678-ABCD-EF01-2345-6789ABCDEF01"
    }
}
