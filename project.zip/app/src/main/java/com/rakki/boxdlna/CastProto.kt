package com.rakki.boxdlna

import java.io.ByteArrayOutputStream

/** Minimal hand-written protobuf for the Cast v2 CastMessage. */
object CastProto {
    class Msg(val src: String, val dst: String, val ns: String, val type: Int, val text: String?, val bin: ByteArray?)

    private fun varint(o: ByteArrayOutputStream, v: Int) {
        var x = v
        while (x >= 0x80) { o.write((x and 0x7F) or 0x80); x = x ushr 7 }
        o.write(x)
    }

    private fun bytes(o: ByteArrayOutputStream, field: Int, b: ByteArray) {
        o.write((field shl 3) or 2)
        varint(o, b.size)
        o.write(b)
    }

    fun encode(m: Msg): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(0x08); o.write(0)                       // protocol_version = CASTV2_1_0
        bytes(o, 2, m.src.toByteArray(Charsets.UTF_8))
        bytes(o, 3, m.dst.toByteArray(Charsets.UTF_8))
        bytes(o, 4, m.ns.toByteArray(Charsets.UTF_8))
        o.write(0x28); o.write(m.type)                  // payload_type
        if (m.type == 0) bytes(o, 6, (m.text ?: "").toByteArray(Charsets.UTF_8))
        else bytes(o, 7, m.bin ?: ByteArray(0))
        return o.toByteArray()
    }

    fun decode(b: ByteArray): Msg? {
        var i = 0
        fun readVarint(): Int {
            var r = 0; var shift = 0
            while (i < b.size) {
                val x = b[i++].toInt() and 0xFF
                r = r or ((x and 0x7F) shl shift)
                if (x < 0x80) return r
                shift += 7
            }
            return r
        }
        var src = ""; var dst = ""; var ns = ""; var type = 0
        var text: String? = null; var bin: ByteArray? = null
        while (i < b.size) {
            val tag = readVarint()
            val field = tag ushr 3
            when (tag and 7) {
                0 -> { val v = readVarint(); if (field == 5) type = v }
                2 -> {
                    val len = readVarint()
                    if (len < 0 || i + len > b.size) return null
                    val d = b.copyOfRange(i, i + len)
                    i += len
                    when (field) {
                        2 -> src = String(d, Charsets.UTF_8)
                        3 -> dst = String(d, Charsets.UTF_8)
                        4 -> ns = String(d, Charsets.UTF_8)
                        6 -> text = String(d, Charsets.UTF_8)
                        7 -> bin = d
                    }
                }
                else -> return null
            }
        }
        return Msg(src, dst, ns, type, text, bin)
    }
}
