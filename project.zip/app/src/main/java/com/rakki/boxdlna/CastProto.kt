package com.rakki.boxdlna

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

object CastProto {
    class Msg(
        val src: String,
        val dst: String,
        val ns: String,
        val type: Int,
        val text: String?,
        val bin: ByteArray?
    )

    fun encode(m: Msg): ByteArray {
        val sBytes = m.src.toByteArray(Charsets.UTF_8)
        val dBytes = m.dst.toByteArray(Charsets.UTF_8)
        val nBytes = m.ns.toByteArray(Charsets.UTF_8)
        
        val bos = ByteArrayOutputStream()
        bos.write(0x0a); writeVarint(bos, sBytes.size.toLong()); bos.write(sBytes)
        bos.write(0x12); writeVarint(bos, dBytes.size.toLong()); bos.write(dBytes)
        bos.write(0x1a); writeVarint(bos, nBytes.size.toLong()); bos.write(nBytes)
        bos.write(0x20); writeVarint(bos, m.type.toLong())
        
        if (m.type == 0 && m.text != null) {
            val tBytes = m.text.toByteArray(Charsets.UTF_8)
            bos.write(0x2a); writeVarint(bos, tBytes.size.toLong()); bos.write(tBytes)
        } else if (m.type == 1 && m.bin != null) {
            bos.write(0x32); writeVarint(bos, m.bin.size.toLong()); bos.write(m.bin)
        }
        return bos.toByteArray()
    }

    fun decode(data: ByteArray): Msg? {
        try {
            var src = "sender-0"
            var dst = "receiver-0"
            var ns = ""
            var type = 0
            var text: String? = null
            var bin: ByteArray? = null

            val bb = ByteBuffer.wrap(data)
            while (bb.hasRemaining()) {
                val tag = readVarintBB(bb)
                val fieldNumber = tag ushr 3
                val wireType = tag and 7
                when (wireType) {
                    0 -> readVarintBB(bb)
                    2 -> {
                        val len = readVarintBB(bb).toInt()
                        val b = ByteArray(len)
                        bb.get(b)
                        when (fieldNumber) {
                            1 -> src = String(b, Charsets.UTF_8)
                            2 -> dst = String(b, Charsets.UTF_8)
                            3 -> ns = String(b, Charsets.UTF_8)
                            5 -> {
                                text = String(b, Charsets.UTF_8)
                                type = 0
                            }
                            6 -> {
                                bin = b
                                type = 1
                            }
                        }
                    }
                    else -> return null
                }
            }
            return Msg(src, dst, ns, type, text, bin)
        } catch (e: Exception) {
            return null
        }
    }

    private fun writeVarint(bos: ByteArrayOutputStream, value: Long) {
        var v = value
        while (v and 0x7FL.inv() != 0L) {
            bos.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
        bos.write((v and 0x7F).toInt())
    }

    private fun readVarintBB(bb: ByteBuffer): Long {
        var result = 0L
        var shift = 0
        while (true) {
            val b = bb.get().toInt()
            result = result or ((b and 0x7F).toLong() shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        return result
    }
}
