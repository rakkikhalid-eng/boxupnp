package com.rakki.boxdlna

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView
    private var server: CastServer? = null
    private var dlna: DlnaService? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        statusText = TextView(this).apply {
            textSize = 18f
            setPadding(40, 40, 40, 40)
        }
        setContentView(statusText)

        val udn = NetUtil.getMacAddress(this) ?: "uuid-box-dlna"
        server = CastServer(this, udn, { 100 }, {})
        server?.start("BoxDLNA Cast")

        dlna = DlnaService(this, udn)
        dlna?.start()

        updateStatus()
    }

    private fun updateStatus() {
        statusText.text = "=== BoxDLNA & Chromecast Receiver ===\n\n" +
                CastDiag.tls + "\n" +
                CastDiag.mdns + "\n" +
                "الاتصال الفعال: " + CastDiag.conns + "\n" +
                "آخر حدث: " + CastDiag.last
    }

    override fun onDestroy() {
        super.onDestroy()
        server?.stop()
        dlna?.stop()
    }
}
