package com.rakki.boxdlna

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import java.io.File
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var tvIp: TextView
    private lateinit var tvOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnCast: Button
    private lateinit var tvCast: TextView
    private lateinit var btnAuth: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor)
        return g
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(Color.parseColor("#26FFFFFF"), 18)
        c.setPadding(dp(18), dp(14), dp(18), dp(14))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        c.addView(label(title, 13f, Color.parseColor("#9FB3C8")))
        return c
    }

    private fun button(text: String, color: Int, click: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 17f
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), round(color, 14, 4, Color.WHITE))
        sl.addState(intArrayOf(android.R.attr.state_pressed), round(color, 14, 4, Color.WHITE))
        sl.addState(intArrayOf(), round(color, 14))
        b.background = sl
        b.stateListAnimator = null
        b.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = File(filesDir, "crash.txt")
        if (crash.exists()) { showCrash(crash.readText()); return }
        try {
            buildUi()
        } catch (t: Throwable) {
            showCrash("UI error\n" + Log.getStackTraceString(t))
            return
        }
        startSvc()
    }

    private val authNames = listOf("صمت (بدون رد)", "رد موقّع بشهادة ذاتية", "رسالة خطأ")

    private fun authMode() = getSharedPreferences("box", MODE_PRIVATE).getInt("authMode", 1)

    private fun cycleAuth() {
        getSharedPreferences("box", MODE_PRIVATE).edit().putInt("authMode", (authMode() + 1) % 3).commit()
        refresh()
    }

    private fun castOff() = getSharedPreferences("box", MODE_PRIVATE).getBoolean("castOff", false)

    private fun updateCastButton() {
        btnCast.text = if (castOff()) "Chromecast: متوقف (اضغط للتفعيل)" else "Chromecast: مفعّل (اضغط للإيقاف)"
    }

    private fun toggleCast() {
        getSharedPreferences("box", MODE_PRIVATE).edit().putBoolean("castOff", !castOff()).commit()
        updateCastButton()
        stopService(Intent(this, DlnaService::class.java))
        Renderer.main.postDelayed({ startSvc() }, 700)
    }

    private fun startSvc() {
        val s = Intent(this, DlnaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s)
    }

    private fun showCrash(trace: String) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))
        col.setBackgroundColor(Color.parseColor("#111827"))
        col.addView(label("حدث خطأ وأُغلق التطبيق. صوّر هذه الشاشة وأرسلها لي. (تم إيقاف Chromecast مؤقتًا)", 16f, Color.WHITE, true))
        val tv = label(trace.take(2800), 11f, Color.parseColor("#FCA5A5"))
        tv.typeface = android.graphics.Typeface.MONOSPACE
        tv.textDirection = View.TEXT_DIRECTION_LTR
        val sv = ScrollView(this)
        sv.addView(tv)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(button("متابعة وحذف التقرير", Color.parseColor("#2563EB")) {
            File(filesDir, "crash.txt").delete()
            recreate()
        })
        setContentView(col)
    }

    private fun buildUi() {
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#0B132B"), Color.parseColor("#1C2541"), Color.parseColor("#3A506B"))
        )
        val frame = FrameLayout(this)
        frame.background = bg

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(dp(16), dp(24), dp(16), dp(24))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_launcher)
        icon.background = round(Color.TRANSPARENT, 18)
        icon.outlineProvider = ViewOutlineProvider.BACKGROUND
        icon.clipToOutline = true
        head.addView(icon, LinearLayout.LayoutParams(dp(72), dp(72)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(14), 0, dp(14), 0)
        titles.addView(label("Box DLNA", 30f, Color.WHITE, true))
        titles.addView(label("استقبال البث من الهاتف: DLNA و Chromecast", 14f, Color.parseColor("#C9D6E2")))
        head.addView(titles)
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.bottomMargin = dp(18)
        col.addView(head, hlp)

        // status
        val c1 = card("الحالة")
        c1.addView(label("●  الخدمة تعمل", 20f, Color.parseColor("#4ADE80"), true))
        col.addView(c1)

        // network
        val c2 = card("عنوان البوكس")
        tvIp = label("…", 20f, Color.WHITE, true)
        c2.addView(tvIp)
        c2.addView(label("افتح هذا العنوان من متصفح الهاتف لإرسال ملف ترجمة", 12f, Color.parseColor("#9FB3C8")))
        col.addView(c2)

        // names
        val c3 = card("يظهر في الهاتف باسم")
        c3.addView(label("DLNA  ›  " + DlnaService.name(this), 17f, Color.WHITE))
        c3.addView(label("Chromecast  ›  Box Chrome", 17f, Color.WHITE))
        col.addView(c3)

        // overlay permission
        val c4 = card("إذن الفتح فوق التطبيقات")
        tvOverlay = label("…", 18f, Color.WHITE, true)
        c4.addView(tvOverlay)
        c4.addView(label("بدونه قد لا يفتح المشغّل إذا كان التطبيق مغلقًا", 12f, Color.parseColor("#9FB3C8")))
        col.addView(c4)

        // remote keys
        val c5 = card("أزرار الريموت أثناء التشغيل")
        c5.addView(label("◀ ▶   رجوع / تقديم 10 ثواني", 15f, Color.WHITE))
        c5.addView(label("OK   إيقاف مؤقت", 15f, Color.WHITE))
        c5.addView(label("▲   تغيير حجم الصورة", 15f, Color.WHITE))
        c5.addView(label("▼ أو MENU   قائمة المشغّل والترجمة", 15f, Color.WHITE))
        c5.addView(label("أحمر / أخضر   تقديم أو تأخير الترجمة", 15f, Color.WHITE))
        col.addView(c5)

        val c6 = card("تشخيص Chromecast")
        tvCast = label("…", 12f, Color.parseColor("#C9D6E2"))
        c6.addView(tvCast)
        col.addView(c6)

        btnCast = button("", Color.parseColor("#475569")) { toggleCast() }
        col.addView(btnCast)
        btnAuth = button("", Color.parseColor("#7C3AED")) { cycleAuth() }
        col.addView(btnAuth)
        updateCastButton()
        btnOverlay = button("السماح بالفتح فوق التطبيقات", Color.parseColor("#2563EB")) { requestOverlay() }
        col.addView(btnOverlay)
        col.addView(button("إيقاف التطبيق نهائيًا", Color.parseColor("#DC2626")) { AppQuit.quit(this) })

        val sv = ScrollView(this)
        sv.isFillViewport = true
        val inner = FrameLayout(this)
        val w = minOf(resources.displayMetrics.widthPixels, dp(640))
        inner.addView(col, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        sv.addView(inner)
        frame.addView(sv)
        setContentView(frame)
    }

    private val loop = object : Runnable {
        override fun run() {
            refresh()
            Renderer.main.postDelayed(this, 2000)
        }
    }

    override fun onResume() {
        super.onResume()
        Renderer.main.post(loop)
    }

    override fun onPause() {
        Renderer.main.removeCallbacks(loop)
        super.onPause()
    }

    private fun refresh() {
        if (!::tvIp.isInitialized) return
        tvCast.text = CastDiag.text()
        if (::btnAuth.isInitialized) btnAuth.text = "طريقة التحقق: " + authNames[authMode()] + "\nاضغط للتبديل"
        val ip = NetUtil.local()?.first
        tvIp.text = if (ip == null) "غير متصل بالشبكة" else "http://" + ip + ":" + DlnaService.httpPort
        val ok = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        tvOverlay.text = if (ok) "مفعّل ✓" else "غير مفعّل ✗"
        tvOverlay.setTextColor(Color.parseColor(if (ok) "#4ADE80" else "#F87171"))
        btnOverlay.visibility = if (ok) View.GONE else View.VISIBLE
    }

    private fun requestOverlay() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "adb shell appops set com.rakki.boxdlna SYSTEM_ALERT_WINDOW allow",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
