package com.rakki.boxdlna

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.content.pm.PackageManager
import android.util.Log
import java.io.File
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.text.InputType
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var tvIp: TextView
    private lateinit var tvOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnCast: Button
    private lateinit var tvCast: TextView
    private lateinit var btnAuth: Button
    private lateinit var btnTls: Button
    private lateinit var tvFiles: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnIgnore: Button
    private lateinit var btnFiles: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor)
        return g
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(Color.parseColor("#1FFFFFFF"), 20, 1, Color.parseColor("#33FFFFFF"))
        c.setPadding(dp(18), dp(14), dp(18), dp(14))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        val tt = label(title.uppercase(), 12f, Color.parseColor("#7FB2FF"), true)
        if (!L.rtl) tt.letterSpacing = 0.12f
        tt.setPadding(0, 0, 0, dp(6))
        c.addView(tt)
        return c
    }

    private fun button(text: String, color: Int, click: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 17f
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), round(color, 14, 4, Color.WHITE))
        sl.addState(intArrayOf(android.R.attr.state_pressed), round(color, 14, 4, Color.WHITE))
        sl.addState(intArrayOf(), round(color, 14))
        b.background = sl
        b.stateListAnimator = null
        b.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = File(filesDir, "crash.txt")
        if (crash.exists()) { showCrash(crash.readText()); return }
        try {
            buildUi()
        } catch (t: Throwable) {
            showCrash("UI error\n" + Log.getStackTraceString(t))
            return
        }
        startSvc()
    }

    private fun authName(i: Int) = L.t("auth$i")

    private fun authMode() = getSharedPreferences("box", MODE_PRIVATE).getInt("authMode", 1)

    private fun cycleAuth() {
        getSharedPreferences("box", MODE_PRIVATE).edit().putInt("authMode", (authMode() + 1) % 3).commit()
        refresh()
    }

    private val tlsNames = listOf("RSA + TLS 1.2/1.3", "EC + TLS 1.2/1.3", "RSA + TLS 1.2 only", "EC + TLS 1.2 only")

    private fun tlsProfile() = getSharedPreferences("box", MODE_PRIVATE).getInt("tlsProfile", 0)

    private fun cycleTls() {
        getSharedPreferences("box", MODE_PRIVATE).edit().putInt("tlsProfile", (tlsProfile() + 1) % 4).commit()
        Toast.makeText(this, L.t("restart_hint"), Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun castOff() = getSharedPreferences("box", MODE_PRIVATE).getBoolean("castOff", false)

    private fun updateCastButton() {
        btnCast.text = if (castOff()) L.t("cast_off") else L.t("cast_on")
    }

    private fun toggleCast() {
        getSharedPreferences("box", MODE_PRIVATE).edit().putBoolean("castOff", !castOff()).commit()
        updateCastButton()
        stopService(Intent(this, DlnaService::class.java))
        Renderer.main.postDelayed({ startSvc() }, 700)
    }

    private fun startSvc() {
        val s = Intent(this, DlnaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s)
    }

    private fun showCrash(trace: String) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))
        col.setBackgroundColor(Color.parseColor("#111827"))
        col.addView(label(L.t("crash"), 16f, Color.WHITE, true))
        val tv = label(trace.take(2800), 11f, Color.parseColor("#FCA5A5"))
        tv.typeface = android.graphics.Typeface.MONOSPACE
        tv.textDirection = View.TEXT_DIRECTION_LTR
        val sv = ScrollView(this)
        sv.addView(tv)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(button(L.t("crash_continue"), Color.parseColor("#2563EB")) {
            File(filesDir, "crash.txt").delete()
            recreate()
        })
        setContentView(col)
    }

    private fun chip(text: String, selected: Boolean, click: () -> Unit): TextView {
        val t = label(text, 15f, Color.WHITE, selected)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(9), dp(16), dp(9))
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), round(Color.parseColor("#3B82F6"), 20, 3, Color.WHITE))
        sl.addState(intArrayOf(), if (selected) round(Color.parseColor("#3B82F6"), 20) else round(Color.parseColor("#26FFFFFF"), 20, 1, Color.parseColor("#44FFFFFF")))
        t.background = sl
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = dp(8)
        lp.leftMargin = dp(8)
        t.layoutParams = lp
        return t
    }

    private fun buildUi() {
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#060A18"), Color.parseColor("#101C45"), Color.parseColor("#1D3A8A"))
        )
        val frame = FrameLayout(this)
        frame.background = bg

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = if (L.rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        col.setPadding(dp(16), dp(24), dp(16), dp(24))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(LogoView(this), LinearLayout.LayoutParams(dp(96), dp(96)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, dp(12), 0)
        titles.addView(label("Box DLNA", 30f, Color.WHITE, true))
        val cap = label("SMART MEDIA RECEIVER", 11f, Color.parseColor("#9DB2D8"))
        cap.letterSpacing = 0.25f
        titles.addView(cap)
        titles.addView(label(L.t("tagline"), 13f, Color.parseColor("#C9D6E2")))
        val ver = try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            "v" + pi.versionName + "  ·  build " + pi.versionCode
        } catch (e: Exception) { "" }
        if (ver.isNotEmpty()) titles.addView(label(ver, 11f, Color.parseColor("#7FB2FF"), true))
        head.addView(titles)
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.bottomMargin = dp(10)
        col.addView(head, hlp)

        // language chips
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.layoutDirection = View.LAYOUT_DIRECTION_LTR
        chips.gravity = Gravity.CENTER_HORIZONTAL
        for (i in 0..2) chips.addView(chip(L.nativeNames[i], L.idx == i) { L.set(this, i); buildUi(); refresh() })
        val clp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.bottomMargin = dp(16)
        col.addView(chips, clp)

        // status
        val c1 = card(L.t("status"))
        c1.addView(label(L.t("svc_on"), 20f, Color.parseColor("#4ADE80"), true))
        col.addView(c1)

        // network
        val c2 = card(L.t("addr"))
        tvIp = label("…", 20f, Color.WHITE, true)
        tvIp.textDirection = View.TEXT_DIRECTION_LTR
        c2.addView(tvIp)
        c2.addView(label(L.t("addr_hint"), 12f, Color.parseColor("#9FB3C8")))
        col.addView(c2)

        // names
        val c3 = card(L.t("shown_as"))
        c3.addView(label("DLNA  ›  " + DlnaService.name(this), 17f, Color.WHITE))
        c3.addView(label("Chromecast  ›  Box Chrome", 17f, Color.WHITE))
        col.addView(c3)

        // overlay permission
        val c4 = card(L.t("overlay"))
        tvOverlay = label("…", 18f, Color.WHITE, true)
        c4.addView(tvOverlay)
        c4.addView(label(L.t("overlay_hint"), 12f, Color.parseColor("#9FB3C8")))
        col.addView(c4)

        // files permission
        val c4b = card(L.t("files"))
        tvFiles = label("…", 18f, Color.WHITE, true)
        c4b.addView(tvFiles)
        c4b.addView(label(L.t("files_hint"), 12f, Color.parseColor("#9FB3C8")))
        col.addView(c4b)

        // OpenSubtitles API
        val cApi = card(L.t("api_card"))
        fun field(hint: String, value: String, pwd: Boolean): EditText {
            val e = EditText(this)
            e.hint = hint
            e.setText(value)
            e.setSingleLine(true)
            e.textSize = 15f
            e.setTextColor(Color.WHITE)
            e.setHintTextColor(Color.parseColor("#7C8AA5"))
            e.inputType = InputType.TYPE_CLASS_TEXT or (if (pwd) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
            e.textDirection = View.TEXT_DIRECTION_LTR
            e.background = round(Color.parseColor("#33000000"), 12, 1, Color.parseColor("#44FFFFFF"))
            e.setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            e.layoutParams = lp
            cApi.addView(e)
            return e
        }
        val fKey = field(L.t("api_key"), Cfg.apiKey(this), false)
        val fUser = field(L.t("api_user"), Cfg.user(this), false)
        val fPass = field(L.t("api_pass"), Cfg.pass(this), true)
        cApi.addView(label(L.t("api_hint"), 12f, Color.parseColor("#9FB3C8")))
        cApi.addView(button(L.t("api_save"), Color.parseColor("#2563EB")) {
            Cfg.save(this, fKey.text.toString(), fUser.text.toString(), fPass.text.toString())
            Toast.makeText(this, L.t("api_saved"), Toast.LENGTH_SHORT).show()
        })
        col.addView(cApi)

        // remote keys
        val c5 = card(L.t("keys"))
        for (k in listOf("k_seek", "k_ok", "k_up", "k_back", "k_color")) c5.addView(label(L.t(k), 15f, Color.WHITE))
        col.addView(c5)

        val cLog = card(L.t("log_card"))
        tvLog = label("", 11f, Color.parseColor("#C9D6E2"))
        tvLog.typeface = Typeface.MONOSPACE
        tvLog.textDirection = View.TEXT_DIRECTION_LTR
        cLog.addView(tvLog)
        col.addView(cLog)

        val c6 = card(L.t("diag"))
        tvCast = label("…", 12f, Color.parseColor("#C9D6E2"))
        c6.addView(tvCast)
        col.addView(c6)

        btnIgnore = button("", Color.parseColor("#B45309")) {
            Renderer.ignoreStop = !Renderer.ignoreStop
            Cfg.setIgnoreStop(this, Renderer.ignoreStop)
            refresh()
        }
        col.addView(btnIgnore)
        btnCast = button("", Color.parseColor("#475569")) { toggleCast() }
        col.addView(btnCast)
        btnAuth = button("", Color.parseColor("#7C3AED")) { cycleAuth() }
        col.addView(btnAuth)
        btnTls = button("", Color.parseColor("#0F766E")) { cycleTls() }
        col.addView(btnTls)
        updateCastButton()
        btnOverlay = button(L.t("allow_overlay"), Color.parseColor("#2563EB")) { requestOverlay() }
        col.addView(btnOverlay)
        btnFiles = button(L.t("allow_files"), Color.parseColor("#2563EB")) { requestFiles() }
        col.addView(btnFiles)
        col.addView(button(L.t("quit_app"), Color.parseColor("#DC2626")) { AppQuit.quit(this) })

        val sv = ScrollView(this)
        sv.isFillViewport = true
        val inner = FrameLayout(this)
        val w = minOf(resources.displayMetrics.widthPixels, dp(640))
        inner.addView(col, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        sv.addView(inner)
        frame.addView(sv)
        setContentView(frame)
    }

    private fun filesOk(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else Build.VERSION.SDK_INT < 23 || checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestFiles() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 7)
        } catch (e: Exception) {
            Toast.makeText(this, "adb shell appops set com.rakki.boxdlna MANAGE_EXTERNAL_STORAGE allow", Toast.LENGTH_LONG).show()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            refresh()
            Renderer.main.postDelayed(this, 2000)
        }
    }

    override fun onResume() {
        super.onResume()
        Renderer.main.post(loop)
    }

    override fun onPause() {
        Renderer.main.removeCallbacks(loop)
        super.onPause()
    }

    private fun refresh() {
        if (!::tvIp.isInitialized) return
        tvCast.text = CastDiag.text()
        if (::btnTls.isInitialized) btnTls.text = L.t("tls") + ": " + tlsNames[tlsProfile()] + "\n" + L.t("tls_hint")
        if (::btnAuth.isInitialized) btnAuth.text = L.t("auth") + ": " + authName(authMode()) + "\n" + L.t("press_toggle")
        val ip = NetUtil.local()?.first
        tvIp.text = if (ip == null) L.t("no_net") else "http://" + ip + ":" + DlnaService.httpPort
        val ok = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        tvOverlay.text = if (ok) L.t("enabled") else L.t("disabled")
        tvOverlay.setTextColor(Color.parseColor(if (ok) "#4ADE80" else "#F87171"))
        btnOverlay.visibility = if (ok) View.GONE else View.VISIBLE
        val fo = filesOk()
        tvFiles.text = if (fo) L.t("enabled") else L.t("disabled")
        tvFiles.setTextColor(Color.parseColor(if (fo) "#4ADE80" else "#F87171"))
        btnFiles.visibility = if (fo) View.GONE else View.VISIBLE
        if (::btnIgnore.isInitialized) btnIgnore.text = L.t("ignore_stop") + ": " + L.t(if (Renderer.ignoreStop) "on" else "off")
        if (::tvLog.isInitialized) tvLog.text = CmdLog.dump(25).ifEmpty { L.t("log_empty") }
        updateCastButton()
    }

    private fun requestOverlay() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "adb shell appops set com.rakki.boxdlna SYSTEM_ALERT_WINDOW allow",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
