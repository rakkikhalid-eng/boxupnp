package com.rakki.boxdlna

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        info = TextView(this).apply { textSize = 22f }
        root.addView(info)
        val btn = Button(this).apply {
            text = "السماح بالفتح فوق التطبيقات (مهم)"
            setOnClickListener { requestOverlay() }
        }
        root.addView(btn)
        setContentView(ScrollView(this).apply { addView(root) })

        val s = Intent(this, DlnaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        Renderer.main.postDelayed({ refresh() }, 1500)
    }

    private fun refresh() {
        val ip = NetUtil.local()?.first ?: "غير متصل بالشبكة"
        val overlay = if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) "مفعّل ✓" else "غير مفعّل ✗"
        info.text = "الاسم في الهاتف: " + DlnaService.name(this) + "\n\n" +
            "العنوان: http://" + ip + ":" + DlnaService.httpPort + "\n" +
            "(لإرسال ترجمة يدويًا افتح هذا العنوان من متصفح الهاتف)\n\n" +
            "إذن الفتح فوق التطبيقات: " + overlay + "\n\n" +
            "الهاتف والبوكس لازم يكونوا على نفس الشبكة."
    }

    private fun requestOverlay() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "adb shell appops set com.rakki.boxdlna SYSTEM_ALERT_WINDOW allow",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
