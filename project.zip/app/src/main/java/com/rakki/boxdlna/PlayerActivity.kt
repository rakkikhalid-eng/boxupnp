package com.rakki.boxdlna

import android.content.Context
import android.os.Bundle
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class PlayerActivity : AppCompatActivity() {
    private lateinit var videoView: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        videoView = VideoView(this)
        setContentView(videoView)

        if (Renderer.uri.isNotEmpty()) {
            videoView.setVideoPath(Renderer.uri)
            videoView.setOnPreparedListener {
                Renderer.durMs = videoView.duration.toLong()
                Renderer.state = "PLAYING"
                if (Renderer.startMs > 0) videoView.seekTo(Renderer.startMs.toInt())
                videoView.start()
            }
            videoView.setOnCompletionListener {
                Renderer.state = "IDLE"
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { videoView.stopPlayback() } catch (e: Exception) {}
    }
}

object Renderer {
    var uri = ""
    var subUrl = ""
    var startMs = 0L
    var durMs = 0L
    var posMs = 0L
    var state = "IDLE"

    fun setUri(u: String, sub: String) {
        uri = u
        subUrl = sub
        startMs = 0
        durMs = 0
        posMs = 0
    }

    fun play(ctx: Context) {
        state = "PLAYING"
        val intent = android.content.Intent(ctx, PlayerActivity::class.java).apply {
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    }

    fun pause() {
        state = "PAUSED_PLAYBACK"
    }

    fun seek(ms: Long) {
        posMs = ms
    }

    fun stop() {
        state = "IDLE"
        uri = ""
    }
}
