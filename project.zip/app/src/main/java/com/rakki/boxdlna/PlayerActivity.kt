package com.rakki.boxdlna

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.abs

class PlayerActivity : Activity() {
    var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var root: FrameLayout
    private lateinit var cueView: CueView
    private lateinit var panel: MenuPanel

    private var cues: List<CueParser.C> = emptyList()
        set(v) { field = v; Renderer.cueCount = v.size }
    private var subOffsetMs: Long
        get() = Renderer.subOffsetMs
        set(v) { Renderer.subOffsetMs = v }
    private var subsEnabled: Boolean
        get() = Renderer.subsEnabled
        set(v) { Renderer.subsEnabled = v }
    private var lastUri = ""
    private var lastKey = ""
    private var loadedSig = ""
    private var gen = 0
    private var aspect = 0
    private var locked = false
    private var lastToast: Toast? = null

    private val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private var speedIdx = 2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- tickers

    private val ticker = object : Runnable {
        override fun run() {
            player?.let { p ->
                Renderer.posMs = p.currentPosition
                val d = p.duration
                Renderer.durMs = if (d == C.TIME_UNSET) 0L else d
            }
            Renderer.main.postDelayed(this, 500)
        }
    }

    private val cueTick = object : Runnable {
        override fun run() {
            updateCue()
            if (hudVisible) updateHud()
            if (syncing) updateSyncStatus()
            // the sender app (and the local server it runs on the phone) was closed: don't stay frozen on screen
            if (bufferingSince > 0 && !syncing && System.currentTimeMillis() - bufferingSince > 25_000 && isLanSource(Renderer.uri)) {
                bufferingSince = 0
                CmdLog.add("source lost (stalled > 25 s)")
                toast(L.t("source_lost"))
                Renderer.stop()
            }
            Renderer.main.postDelayed(this, 100)
        }
    }

    private fun isLanSource(u: String): Boolean {
        val h = u.substringAfter("://").substringBefore('/').substringBefore(':')
        return h.startsWith("192.168.") || h.startsWith("10.") || h.matches(Regex("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*"))
    }

    private fun activeText(t: Long): String {
        var lo = 0
        var hi = cues.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (cues[mid].s <= t) { idx = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (idx < 0) return ""
        val sb = StringBuilder()
        var i = maxOf(0, idx - 3)
        while (i <= idx) {
            if (cues[i].e > t) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(cues[i].t)
            }
            i++
        }
        return sb.toString()
    }

    private fun updateCue() {
        val p = player
        var txt = if (p == null || cues.isEmpty() || !subsEnabled) "" else activeText(p.currentPosition - subOffsetMs)
        if (txt.isEmpty() && panel.isOpen && (panel.tag == "style" || panel.tag == "subs")) txt = L.t("sample")
        if (txt != cueView.text) {
            cueView.text = txt
            cueView.invalidate()
        }
    }

    // ---------------------------------------------------------------- player events

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            bufferingSince = if (playbackState == Player.STATE_BUFFERING) System.currentTimeMillis() else 0L
            sync()
        }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { sync() }
        override fun onPlayerError(error: PlaybackException) {
            CmdLog.add("PLAYER ERROR " + error.errorCodeName + ": " + (error.cause?.message ?: error.message ?: "").take(200))
            toast(L.t("player_error") + ": " + error.errorCodeName)
            Renderer.state = "STOPPED"
            Renderer.changed()
            Renderer.main.postDelayed({ finish() }, 3500)
        }
    }

    private fun sync() {
        val p = player ?: return
        val st = when (p.playbackState) {
            Player.STATE_BUFFERING -> "TRANSITIONING"
            Player.STATE_READY -> if (p.playWhenReady) "PLAYING" else "PAUSED_PLAYBACK"
            else -> "STOPPED"
        }
        if (Renderer.state != st) { Renderer.state = st; Renderer.changed() }
        if (p.playbackState == Player.STATE_ENDED) finish()
    }

    private fun toast(s: String) {
        lastToast?.cancel()
        lastToast = Toast.makeText(this, s, Toast.LENGTH_SHORT)
        lastToast?.show()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        view = PlayerView(this)
        view.useController = false
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cueView = CueView(this)
        root.addView(cueView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        buildHud()
        panel = MenuPanel(this, root) { updateCue() }   // added last = drawn above the time bar
        aspect = SubStyle.aspect(this)
        applyStyle()
        root.post { applyAspect() }

        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setUserAgent("Mozilla/5.0 (Linux; Android 11; Box) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
        val rf = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(arrayOf(AutoSync.rt.processor))
                .build()
        }.setEnableDecoderFallback(true)
        // a bigger buffer: playback survives short network hiccups and the sender going away for a moment
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 2_500, 5_000)
            .setTargetBufferBytes(48 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        val p = ExoPlayer.Builder(this, rf)
            .setLoadControl(lc)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.addListener(listener)
        view.player = p
        player = p
        Renderer.activity = this
        Renderer.main.post(ticker)
        Renderer.main.post(cueTick)
        load(Renderer.wantPlay, takeStart())
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        onPlayRequest()
    }

    override fun onDestroy() {
        Renderer.main.removeCallbacks(ticker)
        Renderer.main.removeCallbacks(cueTick)
        Renderer.main.removeCallbacks(hideHud)
        Renderer.main.removeCallbacks(syncFinish)
        syncGen++
        scan?.cancel()
        AutoSync.rt.collecting = false
        player?.let { Renderer.rememberResume(it.currentPosition, lastKey) }
        player?.release()
        player = null
        if (Renderer.activity === this) {
            Renderer.activity = null
            Renderer.wantPlay = false
            if (Renderer.uri.isNotEmpty()) Renderer.state = "STOPPED"
            Renderer.changed()
        }
        super.onDestroy()
    }

    private fun takeStart(): Long {
        val s = Renderer.startMs
        Renderer.startMs = 0
        return s
    }

    fun onPlayRequest() {
        val p = player ?: return
        if (Renderer.videoKey() != lastKey) load(true, takeStart())
        else {
            // same video: if only the subtitle changed, reload it without restarting playback
            if (Renderer.signature() != loadedSig) reloadSubs()
            p.play()
        }
    }

    private var senderHash = 0
    private var bufferingSince = 0L

    fun reloadSubs() {
        if (player == null) return
        loadedSig = Renderer.signature()
        loadSubs(0, 0)
    }

    /**
     * Loads the active subtitle. For the sender's subtitle it retries while the sender's server is not ready, and
     * checks again a few seconds later in case the file was swapped after the video was announced.
     */
    private fun loadSubs(attempt: Int, verify: Int) {
        val sig = Renderer.signature()
        val manual = Renderer.effectiveManual()
        val url = Renderer.subUrl
        Thread {
            val sub = manual ?: url?.let { SubtitleLoader.fetch(it, cacheDir) }
            val text = try { sub?.file?.readText() } catch (t: Throwable) { null }
            val parsed = try { if (text != null) CueParser.parse(text) else emptyList() } catch (t: Throwable) { emptyList() }
            val lang = if (text != null && manual == null) SubLang.detect(text) else ""
            runOnUiThread {
                if (isFinishing || isDestroyed || Renderer.signature() != sig) return@runOnUiThread
                if (manual != null || url == null) { cues = parsed; return@runOnUiThread }
                if (text == null) {
                    if (attempt < 5) Renderer.main.postDelayed({ loadSubs(attempt + 1, verify) }, 1500L * (attempt + 1))
                    return@runOnUiThread
                }
                val h = text.hashCode()
                if (h != senderHash) {
                    senderHash = h
                    cues = parsed
                    Renderer.senderLang = lang
                    CmdLog.add("sender subtitle: lang=" + (lang.ifEmpty { "?" }) + " lines=" + parsed.size)
                }
                if (verify < 2) Renderer.main.postDelayed({ loadSubs(0, verify + 1) }, if (verify == 0) 3000L else 7000L)
            }
        }.start()
    }

    private fun load(autoplay: Boolean, startMs: Long) {
        val u = Renderer.uri
        if (u.isEmpty()) { finish(); return }
        lastUri = u
        lastKey = Renderer.videoKey()
        if (u.contains(".m3u8", true)) logPlaylist(u)
        refreshTitle()
        loadedSig = Renderer.signature()
        val g = ++gen
        Thread {
            val manual = Renderer.effectiveManual()
            val sub = manual ?: Renderer.subUrl?.let { SubtitleLoader.fetch(it, cacheDir) }
            val text = try { sub?.file?.readText() } catch (t: Throwable) { null }
            val parsed = try { if (text != null) CueParser.parse(text) else emptyList() } catch (t: Throwable) { emptyList() }
            val lang = if (text != null && manual == null) SubLang.detect(text) else ""
            runOnUiThread {
                if (!isFinishing && !isDestroyed && g == gen) {
                    cues = parsed
                    senderHash = if (manual == null) (text?.hashCode() ?: 0) else 0
                    if (manual == null) Renderer.senderLang = lang
                    start(u, autoplay, startMs)
                    if (Renderer.subUrl != null && manual == null) Renderer.main.postDelayed({ loadSubs(0, 1) }, 3000)
                }
            }
        }.start()
    }

    private fun start(u: String, autoplay: Boolean, startMs: Long) {
        val p = player ?: return
        p.setMediaItem(buildItem(u), startMs)
        p.prepare()
        p.playWhenReady = autoplay
    }

    /** Streams are identified by extension or by the DLNA protocolInfo mime type, so odd URLs still open. */
    private fun buildItem(u: String): MediaItem {
        val b = MediaItem.Builder().setUri(u)
        val mime = Regex("protocolInfo=\"[^:\"]*:[^:\"]*:([^:\"]+)").find(Renderer.meta)?.groupValues?.get(1)?.lowercase() ?: ""
        val l = u.lowercase()
        when {
            l.contains(".m3u8") || mime.contains("mpegurl") -> b.setMimeType(MimeTypes.APPLICATION_M3U8)
            l.contains(".mpd") || mime.contains("dash+xml") -> b.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return b.build()
    }

    /** The sender restarted its server on another address: continue the same movie from the current position. */
    fun switchSource() {
        val p = player ?: return
        val u = Renderer.uri
        val pos = p.currentPosition
        val play = p.playWhenReady || Renderer.wantPlay
        lastUri = u
        CmdLog.add("switch source at " + pos + " ms -> " + u.take(100))
        p.setMediaItem(buildItem(u), pos)
        p.prepare()
        p.playWhenReady = play
    }

    private fun logPlaylist(u: String) {
        Thread {
            try {
                val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                val txt = c.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
                CmdLog.add("m3u8 (" + txt.length + " B): " + txt.take(400))
            } catch (e: Exception) {
                CmdLog.add("m3u8 fetch failed: " + (e.message ?: e.javaClass.simpleName))
            }
        }.start()
    }

    // ---------------------------------------------------------------- picture size

    private fun applyAspect() {
        val w = root.width
        val h = root.height
        if (w == 0 || h == 0) { root.post { applyAspect() }; return }
        var lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        when (aspect) {
            0 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            2 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> {
                val r = if (aspect == 3) 16f / 9f else 4f / 3f
                var bw = w
                var bh = (w / r).toInt()
                if (bh > h) { bh = h; bw = (h * r).toInt() }
                lp = FrameLayout.LayoutParams(bw, bh, Gravity.CENTER)
                view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            }
        }
        view.layoutParams = lp
    }

    private fun setAspect(i: Int) {
        aspect = ((i % 5) + 5) % 5
        SubStyle.setAspect(this, aspect)
        applyAspect()
    }

    // ---------------------------------------------------------------- subtitle style / sync

    fun applyStyle() {
        val st = SubStyle.get(this)
        cueView.sizeSp = st.size
        cueView.fillColor = st.color
        cueView.bgArgb = SubStyle.bgArgb(st)
        cueView.outline = st.edge
        cueView.bottomFraction = st.pos / 100f
        cueView.invalidate()
        view.subtitleView?.apply {
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
            setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, st.size)
            setBottomPaddingFraction(st.pos / 100f)
            setStyle(
                CaptionStyleCompat(
                    st.color, SubStyle.bgArgb(st), Color.TRANSPARENT,
                    if (st.edge) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE,
                    Color.BLACK, null
                )
            )
        }
    }

    private fun offsetText(): String = String.format(Locale.US, "%+.1f %s", subOffsetMs / 1000.0, L.t("sec"))

    private fun nudge(ms: Long) {
        subOffsetMs = (subOffsetMs + ms).coerceIn(-600_000L, 600_000L)
        updateCue()
    }

    private fun snapNearest() {
        val p = player ?: return
        if (cues.isEmpty()) { toast(L.t("no_subs")); return }
        val t = p.currentPosition - subOffsetMs
        var best = cues[0]
        var bd = Long.MAX_VALUE
        for (c in cues) {
            val d = abs(c.s - t)
            if (d < bd) { bd = d; best = c }
        }
        subOffsetMs = p.currentPosition - best.s
        updateCue()
        toast(L.t("synced") + ": " + offsetText())
    }

    // ---- automatic sync (audio energy vs subtitle timing)

    private var syncing = false
    private var syncStartAt = 0L
    private var syncMode = 0 // 1 = fast offline scan (video paused), 2 = real-time listening
    private var syncGen = 0
    private var undoOffset: Long? = null
    private val syncFinish = Runnable { finishAutoSync() }

    fun autoSync() = startAutoSync()

    private fun applyOutcome(o: AutoSync.Outcome) {
        when (o.status) {
            1 -> {
                undoOffset = subOffsetMs
                subOffsetMs = o.offsetMs.coerceIn(-600_000L, 600_000L)
                updateCue()
                toast(L.t("synced") + ": " + offsetText() + "  (" + o.agree + "/" + o.total + ")")
            }
            2 -> toast(L.t("sync_already"))
            else -> toast(L.t("sync_fail"))
        }
    }

    private var scan: FastScan? = null

    private fun startAutoSync() {
        val p = player ?: return
        if (syncing) { toast(L.t("sync_busy")); return }
        if (cues.isEmpty()) { toast(L.t("no_subs")); return }
        syncing = true
        syncMode = 1
        syncStartAt = System.currentTimeMillis()
        val wasPlaying = p.playWhenReady
        val pos0 = p.currentPosition
        val dur = p.duration
        val g = ++syncGen
        p.pause()                       // the picture stays paused; a hidden muted player listens at 4x speed
        panel.close()
        statusTv.text = "⏳  " + L.t("sync_scan")
        statusTv.visibility = View.VISIBLE
        val cs = cues
        val center = subOffsetMs
        val centerBin = (center / 100).toInt()
        val item = buildItem(Renderer.uri)
        // up to four places in the film: here, +6 min, -6 min, +12 min (stops early once two agree)
        val starts = ArrayList<Long>()
        starts.add(pos0)
        if (dur != C.TIME_UNSET && dur > 0) {
            for (off in listOf(360_000L, -360_000L, 720_000L)) {
                val s = pos0 + off
                if (s >= 0 && s + 70_000 < dur) starts.add(s)
            }
        }
        val cands = ArrayList<AutoSync.Cand>()
        var tried = 0

        fun conclude(early: AutoSync.Outcome?) {
            val out = early ?: AutoSync.decide(cands, maxOf(1, tried), center)
            syncing = false
            scan = null
            statusTv.visibility = View.GONE
            CmdLog.add("sync result status=" + out.status + " offset=" + out.offsetMs + " agree=" + out.agree + "/" + out.total)
            applyOutcome(out)
            if (wasPlaying) player?.play()
        }

        fun next(i: Int) {
            if (g != syncGen || isFinishing || isDestroyed) return
            if (i >= starts.size) { conclude(null); return }
            statusTv.text = "⏳  " + L.t("sync_scan") + "  " + (i + 1) + "/" + starts.size
            val fs = FastScan(this, item, starts[i], 60_000) { bins ->
                if (g != syncGen || isFinishing || isDestroyed) return@FastScan
                if (bins == null) {
                    CmdLog.add("sync window " + (i + 1) + ": no audio")
                    if (i == 0 && tried == 0) { startRealtimeSync(); return@FastScan }
                    next(i + 1)
                    return@FastScan
                }
                tried++
                Thread {
                    val c = AutoSync.analyzeWindow(AutoSync.Window(starts[i], bins), cs, centerBin)
                    runOnUiThread {
                        if (g != syncGen || isFinishing || isDestroyed) return@runOnUiThread
                        if (c != null) {
                            cands.add(c)
                            CmdLog.add(String.format(Locale.US, "sync window %d: shift=%+.1fs score=%.2f z=%.1f atCurrent=%.2f",
                                i + 1, c.k / 10.0, c.best, c.z, c.atCenter))
                        } else CmdLog.add("sync window " + (i + 1) + ": not enough speech to analyse")
                        if (cands.size >= 2) {
                            val o = AutoSync.decide(cands, tried, center)
                            if (o.status != 0) { conclude(o); return@runOnUiThread }
                        }
                        next(i + 1)
                    }
                }.start()
            }
            scan = fs
            fs.start()
        }
        next(0)
    }

    private fun startRealtimeSync() {
        val p = player ?: return
        syncMode = 2
        syncStartAt = System.currentTimeMillis()
        AutoSync.rt.begin(p.currentPosition)
        p.seekTo(p.currentPosition)   // flush so the audio tap starts exactly at this position
        p.play()
        toast(L.t("sync_start"))
        Renderer.main.postDelayed(syncFinish, 60_000)
    }

    private fun abortSync() {
        if (!syncing) return
        syncing = false
        syncGen++
        scan?.cancel()
        scan = null
        AutoSync.rt.collecting = false
        Renderer.main.removeCallbacks(syncFinish)
        statusTv.visibility = View.GONE
    }

    private fun updateSyncStatus() {
        if (syncMode == 2) {
            val left = maxOf(0, 60 - ((System.currentTimeMillis() - syncStartAt) / 1000).toInt())
            statusTv.text = "⏱  " + L.t("autosync") + "  " + left + L.t("sec")
        }
    }

    private fun finishAutoSync() {
        if (!syncing) return
        syncing = false
        statusTv.visibility = View.GONE
        val bins = AutoSync.rt.end()
        val start = AutoSync.rt.refMs
        val cs = cues
        val center = subOffsetMs
        Thread {
            val r = AutoSync.solveMulti(listOf(AutoSync.Window(start, bins)), cs, center)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (bins.isEmpty()) toast(L.t("sync_noaudio")) else applyOutcome(r)
            }
        }.start()
    }

    // ---------------------------------------------------------------- subtitle search

    private var results: List<SubSearch.Res> = emptyList()
    private var searchState = 0 // 1 loading, 2 done, 3 error
    private var searchErr = ""
    private var searchGen = 0
    private var query: SubSearch.Q? = null

    private fun searchLang(): Int = getSharedPreferences("box", MODE_PRIVATE).getInt("searchLang", 0).coerceIn(0, 2)

    private fun needsFiles(): Boolean =
        Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()

    private fun startSearch(online: Boolean) {
        val g = ++searchGen
        searchState = 1
        results = emptyList()
        searchErr = ""
        val q = SubSearch.current()
        query = q
        Thread {
            var res: List<SubSearch.Res> = emptyList()
            var st = 2
            var err = ""
            try {
                if (online) {
                    if (q == null) { st = 3; err = L.t("no_title") } else res = SubSearch.searchOnline(this, q, searchLang())
                } else res = SubSearch.searchLocal(this, q)
            } catch (t: Throwable) { st = 3; err = L.t("net_error") + ": " + (t.message ?: "").take(90) }
            runOnUiThread {
                if (g == searchGen && !isFinishing && !isDestroyed) {
                    results = res; searchState = st; searchErr = err
                    if (panel.isOpen) panel.render()
                }
            }
        }.start()
    }

    private fun pick(r: SubSearch.Res) {
        toast(L.t("downloading"))
        val f = r.file
        Thread {
            var sub: SubtitleLoader.Sub? = null
            var perr = ""
            try {
                sub = if (f != null) SubtitleLoader.normalize(f.readBytes(), cacheDir, "manual")
                else SubSearch.download(this, r, cacheDir)
            } catch (t: Throwable) { perr = t.message ?: "" }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (sub == null) toast(L.t("sub_error") + (if (perr.isNotEmpty()) ": " + perr.take(80) else ""))
                else {
                    Renderer.applyManual(sub, r.label)
                    toast(L.t("applied"))
                    panel.close()
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- menu pages

    private val textColors = listOf(
        "#FFFFFF" to "c_white", "#FFFF00" to "c_yellow", "#00FFFF" to "c_cyan",
        "#00FF00" to "c_green", "#FFA500" to "c_orange", "#CCCCCC" to "c_lgray"
    ).map { Color.parseColor(it.first) to it.second }

    private val bgColors = listOf(
        "#000000" to "c_black", "#333333" to "c_dgray", "#0D47A1" to "c_blue",
        "#FFFFFF" to "c_white", "#B71C1C" to "c_dred"
    ).map { Color.parseColor(it.first) to it.second }

    private fun cname(c: Int, pal: List<Pair<Int, String>>): String =
        pal.firstOrNull { (it.first and 0xFFFFFF) == (c and 0xFFFFFF) }?.second?.let { L.t(it) } ?: L.t("custom")

    private fun cycle(c: Int, pal: List<Pair<Int, String>>, d: Int): Int {
        val step = if (d == 0) 1 else d
        val i = pal.indexOfFirst { (it.first and 0xFFFFFF) == (c and 0xFFFFFF) }
        val n = if (i < 0) 0 else (i + step + pal.size) % pal.size
        return pal[n].first
    }

    private fun edit(f: (SubStyle.S) -> SubStyle.S) {
        val n = f(SubStyle.get(this))
        SubStyle.save(this, n.size, n.color, n.bg, n.opacity, n.pos, n.edge)
        applyStyle()
    }

    private fun rootPage() = MenuPanel.Page("root", { L.t("options") }, {
        listOf(
            MenuPanel.Item("⚙", { L.t("settings") }, null, true) { panel.push(settingsPage()) },
            MenuPanel.Item("CC", { L.t("subtitles") }, null, true) { panel.push(subsPage()) },
            MenuPanel.Item("🔒", { L.t(if (locked) "unlock" else "lock") }, { L.t(if (locked) "on" else "off") }, false) {
                locked = !locked
                toast(L.t(if (locked) "locked_t" else "unlocked_t"))
            },
            MenuPanel.Item("⏹", { L.t("stop") }) { d -> if (d == 0) Renderer.stop() }
        )
    })

    private fun settingsPage() = MenuPanel.Page("settings", { L.t("settings") }, {
        listOf(
            MenuPanel.Item("▭", { L.t("aspect") }, { L.t("asp$aspect") }) { d -> setAspect(aspect + (if (d == 0) 1 else d)) },
            MenuPanel.Item("⏩", { L.t("speed") }, { String.format(Locale.US, "x%.2f", speeds[speedIdx]).trimEnd('0').trimEnd('.') }) { d ->
                speedIdx = (speedIdx + (if (d == 0) 1 else d) + speeds.size) % speeds.size
                player?.setPlaybackSpeed(speeds[speedIdx])
            },
            MenuPanel.Item("🌐", { L.t("language") }, { L.nativeNames[L.idx] }) { d ->
                L.set(this, L.idx + (if (d == 0) 1 else d))
                refreshTitle()
            },
            MenuPanel.Item("⏸", { L.t("ignore_stop") }, { L.t(if (Renderer.ignoreStop) "on" else "off") }) { d ->
                Renderer.ignoreStop = if (d == 0) !Renderer.ignoreStop else d > 0
                Cfg.setIgnoreStop(this, Renderer.ignoreStop)
            },
            MenuPanel.Item("⏻", { L.t("quit") }) { d -> if (d == 0) AppQuit.quit(this) }
        )
    })

    private fun subsPage() = MenuPanel.Page("subs", { L.t("subtitles") }, {
        listOf(
            MenuPanel.Item("🔍", { L.t("search_box") }, null, true) { panel.push(searchPage(false)) },
            MenuPanel.Item("☁", { L.t("search_online") }, { "OpenSubtitles" }, true) { panel.push(searchPage(true)) },
            MenuPanel.Item("🈯", { L.t("search_lang") }, { L.t("lang_" + SubSearch.langIds[searchLang()]) }) { d ->
                val n = (searchLang() + (if (d == 0) 1 else d) + 3) % 3
                getSharedPreferences("box", MODE_PRIVATE).edit().putInt("searchLang", n).apply()
            },
            MenuPanel.Item("CC", { L.t("subs_show") }, { L.t(if (subsEnabled) "on" else "off") }) { subsEnabled = !subsEnabled },
            MenuPanel.Item("⏱", { L.t("delay") }, { offsetText() }) { d ->
                if (d == 0) { subOffsetMs = 0; updateCue() } else nudge(d * 100L)
            },
            MenuPanel.Item("◎", { L.t("quicksync") }) { d -> if (d == 0) snapNearest() },
            MenuPanel.Item("↶", { L.t("undo_sync") }, { undoOffset?.let { String.format(Locale.US, "%+.1f %s", it / 1000.0, L.t("sec")) } ?: "—" }) { d ->
                val u = undoOffset
                if (d == 0 && u != null) { subOffsetMs = u; undoOffset = null; updateCue(); toast(L.t("undone")) }
            },
            MenuPanel.Item("✨", { L.t("autosync") }) { d -> if (d == 0) startAutoSync() },
            MenuPanel.Item("Aa", { L.t("appearance") }, null, true) { panel.push(stylePage()) }
        )
    })

    private fun stylePage() = MenuPanel.Page("style", { L.t("appearance") }, {
        listOf(
            MenuPanel.Item("Aa", { L.t("font_size") }, { SubStyle.get(this).size.toInt().toString() }) { d ->
                edit { it.copy(size = (it.size + 2 * (if (d == 0) 1 else d)).coerceIn(14f, 70f)) }
            },
            MenuPanel.Item("●", { L.t("font_color") }, { cname(SubStyle.get(this).color, textColors) }) { d ->
                edit { it.copy(color = cycle(it.color, textColors, d)) }
            },
            MenuPanel.Item("■", { L.t("bg_color") }, { cname(SubStyle.get(this).bg, bgColors) }) { d ->
                edit { it.copy(bg = cycle(it.bg, bgColors, d)) }
            },
            MenuPanel.Item("◐", { L.t("bg_opacity") }, {
                val o = SubStyle.get(this).opacity
                if (o == 0) L.t("transparent") else "$o%"
            }) { d -> edit { it.copy(opacity = (it.opacity + 10 * (if (d == 0) 1 else d)).coerceIn(0, 100)) } },
            MenuPanel.Item("↕", { L.t("height") }, { SubStyle.get(this).pos.toString() + "%" }) { d ->
                edit { it.copy(pos = (it.pos + 2 * (if (d == 0) 1 else d)).coerceIn(0, 60)) }
            },
            MenuPanel.Item("▢", { L.t("outline") }, { L.t(if (SubStyle.get(this).edge) "on" else "off") }) { d ->
                edit { it.copy(edge = if (d == 0) !it.edge else d > 0) }
            },
            MenuPanel.Item("↺", { L.t("reset_style") }) { d -> if (d == 0) { SubStyle.reset(this); applyStyle() } }
        )
    })

    private fun editTitle(online: Boolean) {
        val edit = EditText(this)
        edit.setSingleLine(true)
        edit.setText(SubSearch.current()?.title ?: SubSearch.rawTitle())
        edit.setSelection(edit.text.length)
        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(L.t("edit_title"))
            .setView(edit)
            .setPositiveButton("OK") { _, _ ->
                val t = edit.text.toString().trim()
                Renderer.ovTitle = t.ifEmpty { null }
                Renderer.ovSeason = -1; Renderer.ovEpisode = -1; Renderer.ovYear = null
                startSearch(online)
                if (panel.isOpen) panel.render()
            }
            .setNegativeButton(L.t("cancel"), null)
            .create()
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }

    private fun searchPage(online: Boolean) = MenuPanel.Page(
        if (online) "online" else "box",
        { L.t(if (online) "search_online" else "search_box") },
        {
            val items = ArrayList<MenuPanel.Item>()
            val q = SubSearch.current()
            items.add(MenuPanel.Item("🎬", { (q?.display() ?: L.t("no_title")) + "\n« " + SubSearch.rawTitle() + " »" }) { })
            if (online) items.add(MenuPanel.Item("☁", { L.t(if (Cfg.apiKey(this).isNotEmpty()) "src_api" else "src_free") }) { })
            items.add(MenuPanel.Item("✎", { L.t("edit_title") }, { q?.title ?: "—" }) { d -> if (d == 0) editTitle(online) })
            items.add(MenuPanel.Item("S", { L.t("season") }, { if ((q?.season ?: 0) > 0) q!!.season.toString() else "—" }) { d ->
                val cur = q?.season ?: 0
                val n = maxOf(0, cur + (if (d == 0) 1 else d))
                Renderer.ovSeason = n
                if (n > 0 && (q?.episode ?: 0) == 0) Renderer.ovEpisode = 1
            })
            items.add(MenuPanel.Item("E", { L.t("episode") }, { if ((q?.season ?: 0) > 0) q!!.episode.toString() else "—" }) { d ->
                if ((q?.season ?: 0) > 0) Renderer.ovEpisode = maxOf(1, (q?.episode ?: 1) + (if (d == 0) 1 else d))
            })
            items.add(MenuPanel.Item("📅", { L.t("year") }, { q?.year?.ifEmpty { "—" } ?: "—" }) { d ->
                val cur = q?.year?.toIntOrNull() ?: 2020
                Renderer.ovYear = (cur + (if (d == 0) 1 else d)).coerceIn(1900, 2100).toString()
            })
            items.add(MenuPanel.Item("🔍", { L.t("do_search") }) { d -> if (d == 0) startSearch(online) })
            when {
                searchState == 1 -> items.add(MenuPanel.Item("⏳", { L.t("searching") }) { })
                searchState == 3 -> items.add(MenuPanel.Item("⚠", { searchErr }) { })
                results.isEmpty() -> items.add(MenuPanel.Item("∅", { L.t(if (!online && needsFiles()) "no_perm" else "no_results") }) { })
                else -> for (r in results) items.add(MenuPanel.Item("CC", { r.label + "\n" + r.info }) { d -> if (d == 0) pick(r) })
            }
            items
        },
        { startSearch(online) }
    )

    private fun selectAudio(g: androidx.media3.common.Tracks.Group, i: Int) {
        val pl = player ?: return
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
        Renderer.main.postDelayed({ if (panel.isOpen) panel.render() }, 400)
    }

    private fun audioItems(): List<MenuPanel.Item> {
        val pl = player ?: return emptyList()
        val out = ArrayList<MenuPanel.Item>()
        var n = 0
        for (g in pl.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                n++
                val f = g.getTrackFormat(i)
                val lang = f.language?.takeIf { it.isNotEmpty() && it != "und" }?.let { Locale(it).displayLanguage } ?: ("Audio " + n)
                val codec = (f.sampleMimeType ?: "").substringAfter('/').uppercase()
                val ch = if (f.channelCount > 0) f.channelCount.toString() + "ch" else ""
                val sel = g.isTrackSelected(i)
                val grp = g
                val idx = i
                out.add(MenuPanel.Item("🔊", { lang + (if (sel) "  ✓" else "") }, { listOf(codec, ch).filter { it.isNotEmpty() }.joinToString(" ") }) { d ->
                    if (d == 0) selectAudio(grp, idx)
                })
            }
        }
        if (out.isEmpty()) out.add(MenuPanel.Item("∅", { L.t("no_results") }) { })
        return out
    }

    private fun audioPage() = MenuPanel.Page("audio", { L.t("p_audio") }, { audioItems() })

    private fun openMenu() {
        hideHudNow()
        panel.open(rootPage())
        updateCue()
    }

    // ---------------------------------------------------------------- player controls (HUD) – icons drawn in code

    private val K_PLAY = 0
    private val K_PAUSE = 1
    private val K_REW = 2
    private val K_FWD = 3
    private val K_ASPECT = 4
    private val K_SPEED = 5
    private val K_CC = 6
    private val K_AUDIO = 7
    private val K_LOCK = 8
    private val K_UNLOCK = 9
    private val K_BACK = 10
    private val K_MENU = 11

    private inner class IconView(ctx: Context, var kind: Int) : View(ctx) {
        var color = Color.WHITE
        var inner = Color.parseColor("#14161D")
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        fun look(focused: Boolean) {
            color = if (focused) Color.parseColor("#14161D") else Color.WHITE
            inner = if (focused) Color.WHITE else Color.parseColor("#14161D")
            invalidate()
        }

        private fun lines(c: Canvas, vararg pts: Float) {
            path.reset()
            path.moveTo(pts[0], pts[1])
            var i = 2
            while (i < pts.size) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
            c.drawPath(path, p)
        }

        override fun onDraw(c: Canvas) {
            val s = minOf(width, height) / 24f
            c.save()
            c.translate((width - 24 * s) / 2, (height - 24 * s) / 2)
            c.scale(s, s)
            p.color = color
            p.style = Paint.Style.FILL
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = 1.9f
            when (kind) {
                K_PLAY -> {
                    path.reset(); path.moveTo(7f, 4f); path.lineTo(20f, 12f); path.lineTo(7f, 20f); path.close()
                    c.drawPath(path, p)
                }
                K_PAUSE -> {
                    c.drawRoundRect(RectF(6f, 4f, 10f, 20f), 1f, 1f, p)
                    c.drawRoundRect(RectF(14f, 4f, 18f, 20f), 1f, 1f, p)
                }
                K_REW, K_FWD -> {
                    c.save()
                    if (kind == K_REW) c.scale(-1f, 1f, 12f, 12f)
                    p.style = Paint.Style.STROKE
                    c.drawArc(RectF(4f, 5.5f, 20f, 21.5f), -45f, 285f, false, p)
                    val ang = Math.toRadians(240.0)
                    val ex = (12 + 8 * Math.cos(ang)).toFloat()
                    val ey = (13.5 + 8 * Math.sin(ang)).toFloat()
                    val vx = (-Math.sin(ang)).toFloat()
                    val vy = Math.cos(ang).toFloat()
                    p.style = Paint.Style.FILL
                    path.reset()
                    path.moveTo(ex + vx * 3.4f, ey + vy * 3.4f)
                    path.lineTo(ex - vy * 3f, ey + vx * 3f)
                    path.lineTo(ex + vy * 3f, ey - vx * 3f)
                    path.close()
                    c.drawPath(path, p)
                    c.restore()
                    p.textAlign = Paint.Align.CENTER
                    p.textSize = 7.6f
                    p.typeface = Typeface.DEFAULT_BOLD
                    c.drawText("10", 12f, 16.3f, p)
                }
                K_ASPECT -> {
                    p.style = Paint.Style.STROKE
                    lines(c, 3f, 10f, 3f, 6f, 7f, 6f)
                    lines(c, 17f, 6f, 21f, 6f, 21f, 10f)
                    lines(c, 21f, 14f, 21f, 18f, 17f, 18f)
                    lines(c, 7f, 18f, 3f, 18f, 3f, 14f)
                    c.drawRect(9f, 10f, 15f, 14f, p)
                }
                K_SPEED -> {
                    p.style = Paint.Style.STROKE
                    c.drawArc(RectF(3f, 5f, 21f, 23f), 150f, 240f, false, p)
                    lines(c, 12f, 14f, 16.5f, 9.5f)
                    p.style = Paint.Style.FILL
                    c.drawCircle(12f, 14f, 1.7f, p)
                }
                K_CC -> {
                    c.drawRoundRect(RectF(2.5f, 5f, 21.5f, 19f), 3f, 3f, p)
                    p.color = inner
                    p.textAlign = Paint.Align.CENTER
                    p.textSize = 8.4f
                    p.typeface = Typeface.DEFAULT_BOLD
                    c.drawText("CC", 12f, 14.8f, p)
                }
                K_AUDIO -> {
                    c.drawRoundRect(RectF(6f, 2.5f, 18f, 21.5f), 3f, 3f, p)
                    p.color = inner
                    c.drawCircle(12f, 8f, 2.1f, p)
                    c.drawCircle(12f, 15.2f, 3.4f, p)
                }
                K_LOCK -> {
                    c.drawRoundRect(RectF(5f, 10f, 19f, 21.5f), 2.5f, 2.5f, p)
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 2.2f
                    c.drawArc(RectF(8f, 3f, 16f, 13f), 180f, 180f, false, p)
                    lines(c, 8f, 8f, 8f, 10.5f)
                    lines(c, 16f, 8f, 16f, 10.5f)
                }
                K_UNLOCK -> {
                    c.drawRoundRect(RectF(5f, 10f, 19f, 21.5f), 2.5f, 2.5f, p)
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 2.2f
                    c.drawArc(RectF(8f, 1.5f, 16f, 11.5f), 180f, 180f, false, p)
                    lines(c, 8f, 6.5f, 8f, 10.5f)
                }
                K_BACK -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 2.3f
                    lines(c, 20f, 12f, 5f, 12f)
                    lines(c, 11f, 6f, 5f, 12f, 11f, 18f)
                }
                K_MENU -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 2.3f
                    lines(c, 4f, 6f, 20f, 6f)
                    lines(c, 4f, 12f, 20f, 12f)
                    lines(c, 4f, 18f, 20f, 18f)
                }
            }
            c.restore()
        }
    }

    private inner class SeekView(ctx: Context) : View(ctx) {
        var frac = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val cy = h / 2
            val th = dp(14).toFloat()
            val gap = dp(8).toFloat()
            val x = (w * frac).coerceIn(0f, w)
            p.color = Color.parseColor("#6B6485")
            c.drawRoundRect(minOf(w, x + gap), cy - th / 2, w, cy + th / 2, th / 2, th / 2, p)
            p.color = Color.WHITE
            if (x - gap > 0) c.drawRoundRect(0f, cy - th / 2, x - gap, cy + th / 2, th / 2, th / 2, p)
            c.drawRoundRect(x - dp(3), cy - dp(15), x + dp(3), cy + dp(15), dp(3).toFloat(), dp(3).toFloat(), p)
        }
    }

    private class Btn(val box: FrameLayout, val icon: IconView)

    private lateinit var hudBottom: LinearLayout
    private lateinit var hudTop: LinearLayout
    private lateinit var hudCenter: LinearLayout
    private lateinit var pillBar: LinearLayout
    private lateinit var seekView: SeekView
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvSub: TextView
    private lateinit var tvInfo: TextView
    private lateinit var statusTv: TextView
    private lateinit var lockBtn: Btn
    private val centerBtns = ArrayList<Btn>()
    private val pillItems = ArrayList<LinearLayout>()
    private val pillIcons = ArrayList<IconView>()
    private val pillTexts = ArrayList<TextView>()
    private var hudVisible = false
    private var controlsMode = false
    private var focusRow = 0      // 0 = center buttons, 1 = bottom pill
    private var focusIdx = 1
    private var pillIdx = 0
    private val hideHud = Runnable { hideHudNow() }

    private fun fmt(ms: Long): String {
        val s = maxOf(0L, ms) / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun gradient(top: Boolean): GradientDrawable =
        GradientDrawable(
            if (top) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(Color.parseColor("#E6000000"), Color.TRANSPARENT)
        )

    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(kind: Int, boxDp: Int, padDp: Int, click: () -> Unit): Btn {
        val box = FrameLayout(this)
        val ic = IconView(this, kind)
        box.addView(ic, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
        box.isClickable = true
        box.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(dp(boxDp), dp(boxDp))
        box.layoutParams = lp
        return Btn(box, ic)
    }

    private fun pill(text: String, color: Int, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(22).toFloat()
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor)
        return g
    }

    private fun buildHud() {
        // ---- bottom: progress, time pills, options pill
        hudBottom = LinearLayout(this)
        hudBottom.orientation = LinearLayout.VERTICAL
        hudBottom.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hudBottom.background = gradient(false)
        hudBottom.setPadding(dp(28), dp(44), dp(28), dp(16))
        hudBottom.visibility = View.GONE

        seekView = SeekView(this)
        hudBottom.addView(seekView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))

        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        tvPos = txt("00:00", 15f, Color.WHITE, true)
        tvDur = txt("00:00", 15f, Color.WHITE, true)
        for (t in listOf(tvPos, tvDur)) {
            t.setPadding(dp(18), dp(7), dp(18), dp(7))
            t.background = pill("", Color.parseColor("#55000000"), Color.parseColor("#66FFFFFF"))
        }
        times.addView(tvPos)
        times.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        times.addView(tvDur)
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = dp(2)
        hudBottom.addView(times, tlp)

        pillBar = LinearLayout(this)
        pillBar.orientation = LinearLayout.HORIZONTAL
        pillBar.gravity = Gravity.CENTER
        pillBar.background = pill("", Color.parseColor("#B3101018"), Color.parseColor("#55FFFFFF"))
        pillBar.setPadding(dp(10), dp(6), dp(10), dp(6))
        val kinds = listOf(K_ASPECT, K_SPEED, K_CC, K_AUDIO, K_MENU)
        for ((i, k) in kinds.withIndex()) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.HORIZONTAL
            item.gravity = Gravity.CENTER_VERTICAL
            item.setPadding(dp(14), dp(9), dp(16), dp(9))
            val ic = IconView(this, k)
            item.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            val t = txt("", 15f, Color.WHITE, true)
            t.setPadding(dp(8), 0, 0, 0)
            item.addView(t)
            item.isClickable = true
            item.setOnClickListener { pillIdx = i; focusRow = 1; activatePill() }
            pillBar.addView(item)
            pillItems.add(item); pillIcons.add(ic); pillTexts.add(t)
        }
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = dp(10)
        hudBottom.addView(pillBar, plp)
        root.addView(hudBottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        // ---- top: title block, lock, back
        hudTop = LinearLayout(this)
        hudTop.orientation = LinearLayout.HORIZONTAL
        hudTop.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hudTop.background = gradient(true)
        hudTop.setPadding(dp(26), dp(14), dp(20), dp(40))
        hudTop.visibility = View.GONE
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        tvTitle = txt("", 26f, Color.WHITE, true)
        tvTitle.maxLines = 1
        tvTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        tvSub = txt("", 19f, Color.parseColor("#E2E6EE"))
        tvSub.maxLines = 1
        tvSub.ellipsize = android.text.TextUtils.TruncateAt.END
        tvInfo = txt("", 15f, Color.parseColor("#AEB8CC"))
        titles.addView(tvTitle)
        titles.addView(tvSub)
        titles.addView(tvInfo)
        hudTop.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        lockBtn = btn(K_LOCK, 50, 13) { toggleLock() }
        lockBtn.box.background = pill("", Color.parseColor("#55000000")).also { it.shape = GradientDrawable.OVAL }
        val backBtn = btn(K_BACK, 50, 13) { finish() }
        backBtn.box.background = pill("", Color.parseColor("#55000000")).also { it.shape = GradientDrawable.OVAL }
        val l1 = LinearLayout.LayoutParams(dp(50), dp(50)); l1.leftMargin = dp(12)
        hudTop.addView(lockBtn.box, l1)
        val l2 = LinearLayout.LayoutParams(dp(50), dp(50)); l2.leftMargin = dp(12)
        hudTop.addView(backBtn.box, l2)
        root.addView(hudTop, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // ---- center: rewind 10 / play-pause / forward 10
        hudCenter = LinearLayout(this)
        hudCenter.orientation = LinearLayout.HORIZONTAL
        hudCenter.gravity = Gravity.CENTER_VERTICAL
        hudCenter.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hudCenter.visibility = View.GONE
        val specs = listOf(Triple(K_REW, 84, 12), Triple(K_PLAY, 112, 24), Triple(K_FWD, 84, 12))
        for ((i, sp) in specs.withIndex()) {
            val b = btn(sp.first, sp.second, sp.third) { focusRow = 0; focusIdx = i; activateFocus() }
            val lp = LinearLayout.LayoutParams(dp(sp.second), dp(sp.second))
            lp.setMargins(dp(26), 0, dp(26), 0)
            hudCenter.addView(b.box, lp)
            centerBtns.add(b)
        }
        root.addView(hudCenter, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // ---- status chip (sync)
        statusTv = txt("", 16f, Color.WHITE, true)
        statusTv.setPadding(dp(16), dp(8), dp(16), dp(8))
        statusTv.background = pill("", Color.parseColor("#CC1B1D26"))
        statusTv.visibility = View.GONE
        val slp2 = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        slp2.topMargin = dp(18)
        root.addView(statusTv, slp2)
        buildPopup()
    }

    private fun refreshTitle() {
        val q = SubSearch.current()
        tvTitle.text = q?.title ?: SubSearch.rawTitle()
        val sub = ArrayList<String>()
        if (q != null && q.season > 0) sub.add("S${q.season}E${q.episode}")
        if (q != null && q.year.isNotEmpty()) sub.add(q.year)
        tvSub.text = sub.joinToString(" • ")
        tvSub.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun speedLabel(): String = speedText(speeds[speedIdx])

    private fun showHud(controls: Boolean) {
        hudVisible = true
        if (controls) controlsMode = true
        applyHudVisibility()
        updateHud()
        Renderer.main.removeCallbacks(hideHud)
        Renderer.main.postDelayed(hideHud, if (controlsMode) 7000 else 3000)
    }

    private fun hideHudNow() {
        Renderer.main.removeCallbacks(hideHud)
        if (::popScroll.isInitialized) popScroll.visibility = View.GONE
        hudVisible = false
        controlsMode = false
        applyHudVisibility()
    }

    private fun applyHudVisibility() {
        hudBottom.visibility = if (hudVisible) View.VISIBLE else View.GONE
        pillBar.visibility = if (hudVisible && controlsMode) View.VISIBLE else View.GONE
        val c = if (hudVisible && controlsMode) View.VISIBLE else View.GONE
        hudTop.visibility = c
        hudCenter.visibility = c
    }

    private fun updateHud() {
        val p = player ?: return
        val d = p.duration
        val dur = if (d == C.TIME_UNSET) 0L else d
        val pos = p.currentPosition
        tvPos.text = fmt(pos)
        tvDur.text = fmt(dur)
        seekView.frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        seekView.invalidate()
        if (!controlsMode) return
        val h = p.videoSize.height
        tvInfo.text = if (h > 0) "${h}P" else ""
        tvInfo.visibility = if (h > 0) View.VISIBLE else View.GONE
        lockBtn.icon.kind = if (locked) K_UNLOCK else K_LOCK
        lockBtn.icon.invalidate()
        centerBtns[1].icon.kind = if (p.playWhenReady) K_PAUSE else K_PLAY
        for ((i, b) in centerBtns.withIndex()) {
            val f = focusRow == 0 && focusIdx == i
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(if (f) Color.WHITE else Color.TRANSPARENT)
            b.box.background = g
            b.icon.look(f)
            b.icon.invalidate()
        }
        val labels = listOf(L.t("p_fit"), speedLabel(), L.t("p_subs"), L.t("p_audio"), L.t("p_options"))
        for (i in pillItems.indices) {
            val f = focusRow == 1 && pillIdx == i
            pillItems[i].background = if (f) pill("", Color.WHITE) else null
            pillTexts[i].text = labels[i]
            pillTexts[i].setTextColor(if (f) Color.parseColor("#14161D") else Color.WHITE)
            pillIcons[i].look(f)
        }
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.playWhenReady) p.pause() else p.play()
    }

    private fun toggleLock() {
        locked = !locked
        toast(L.t(if (locked) "locked_t" else "unlocked_t"))
        showHud(true)
    }

    private fun activateFocus() {
        when (focusIdx) {
            0 -> seekBy(-10_000)
            1 -> togglePlay()
            2 -> seekBy(10_000)
        }
        showHud(true)
    }

    // ---------------------------------------------------------------- pop-up lists above the bottom buttons

    private class PopItem(val label: String, val checked: Boolean, val act: () -> Unit)

    private lateinit var popScroll: ScrollView
    private lateinit var popList: LinearLayout
    private var popItems: List<PopItem> = emptyList()
    private var popSel = 0
    private val popupOpen: Boolean get() = ::popScroll.isInitialized && popScroll.visibility == View.VISIBLE

    private fun buildPopup() {
        popList = LinearLayout(this)
        popList.orientation = LinearLayout.VERTICAL
        popList.setPadding(dp(8), dp(8), dp(8), dp(8))
        popScroll = ScrollView(this)
        popScroll.addView(popList)
        popScroll.isVerticalScrollBarEnabled = false
        popScroll.background = pill("", Color.parseColor("#F2171A22"), Color.parseColor("#55FFFFFF")).also { it.cornerRadius = dp(18).toFloat() }
        popScroll.visibility = View.GONE
        root.addView(popScroll, FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.LEFT))
    }

    private fun showPopup(anchor: Int, items: List<PopItem>) {
        popItems = items
        popSel = items.indexOfFirst { it.checked }.let { if (it < 0) 0 else it }
        Renderer.main.removeCallbacks(hideHud)       // keep the bar on screen while the list is open
        popScroll.layoutDirection = if (L.rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val loc = IntArray(2)
        pillItems[anchor].getLocationInWindow(loc)
        val w = dp(300)
        val lp = popScroll.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = (loc[0] - dp(6)).coerceIn(dp(8), maxOf(dp(8), root.width - w - dp(8)))
        lp.bottomMargin = maxOf(dp(8), root.height - loc[1] + dp(10))
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
        popScroll.layoutParams = lp
        renderPopup()
        popScroll.visibility = View.VISIBLE
        val maxH = (root.height * 0.55f).toInt()
        popScroll.post {
            if (popScroll.height > maxH) { lp.height = maxH; popScroll.layoutParams = lp }
        }
    }

    private fun renderPopup() {
        popList.removeAllViews()
        var selView: View? = null
        for ((i, item) in popItems.withIndex()) {
            val t = txt((if (item.checked) "✓  " else "     ") + item.label, 16f, Color.WHITE, item.checked)
            t.setPadding(dp(14), dp(11), dp(14), dp(11))
            t.maxLines = 2
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            val g = GradientDrawable()
            g.cornerRadius = dp(12).toFloat()
            g.setColor(if (i == popSel) MenuPanel.ACCENT else Color.TRANSPARENT)
            t.background = g
            t.isClickable = true
            t.setOnClickListener { popSel = i; popActivate() }
            popList.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (i == popSel) selView = t
        }
        val sv = selView
        popScroll.post { if (sv != null) popScroll.smoothScrollTo(0, maxOf(0, sv.top - popScroll.height / 2 + sv.height / 2)) }
    }

    private fun closePopup(restoreBar: Boolean) {
        if (!popupOpen) return
        popScroll.visibility = View.GONE
        if (restoreBar) showHud(true)
    }

    private fun popActivate() {
        val item = popItems.getOrNull(popSel) ?: return
        closePopup(false)
        item.act()
        if (!panel.isOpen) showHud(true)
    }

    private fun popupKey(k: Int) {
        val n = popItems.size
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP -> if (n > 0) { popSel = (popSel - 1 + n) % n; renderPopup() }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (n > 0) { popSel = (popSel + 1) % n; renderPopup() }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> popActivate()
            KeyEvent.KEYCODE_DPAD_LEFT -> { closePopup(false); pillIdx = maxOf(0, pillIdx - 1); showHud(true) }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { closePopup(false); pillIdx = minOf(4, pillIdx + 1); showHud(true) }
            else -> closePopup(true)       // Back / Menu
        }
    }

    private fun speedText(v: Float): String = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.') + "x"

    private fun aspectPop(): List<PopItem> = (0..4).map { i -> PopItem(L.t("asp$i"), i == aspect) { setAspect(i) } }

    private fun speedPop(): List<PopItem> = speeds.indices.map { i ->
        PopItem(speedText(speeds[i]), i == speedIdx) { speedIdx = i; player?.setPlaybackSpeed(speeds[i]) }
    }

    private fun applyHistory(e: SubHistory.Entry) {
        Renderer.applyManual(SubtitleLoader.Sub(java.io.File(e.path), "application/x-subrip"), e.label)
        toast(L.t("applied"))
    }

    private fun subsPop(): List<PopItem> {
        val out = ArrayList<PopItem>()
        out.add(PopItem(L.t("sub_off"), !subsEnabled) { subsEnabled = false; updateCue() })
        val sender = Renderer.subUrl
        if (sender != null) {
            val ln = SubLang.name(Renderer.senderLang)
            out.add(PopItem(L.t("sub_sender") + (if (ln.isNotEmpty()) " · $ln" else "") + (if (cues.isNotEmpty() && Renderer.effectiveManual() == null) "  (" + cues.size + ")" else ""), subsEnabled && Renderer.effectiveManual() == null) {
                Renderer.useSenderSub()
            })
        }
        for (e in SubHistory.list(Renderer.appCtx, Renderer.uri)) {
            val ln = SubLang.name(SubLang.detectFile(e.path))
            out.add(PopItem(e.label + (if (ln.isNotEmpty()) " · $ln" else ""), subsEnabled && Renderer.activeSubPath == e.path) { applyHistory(e) })
        }
        out.add(PopItem("⚙  " + L.t("sub_settings"), false) { openMenuTo { subsPage() } })
        return out
    }

    private fun audioPop(): List<PopItem> {
        val pl = player ?: return emptyList()
        val out = ArrayList<PopItem>()
        var n = 0
        for (g in pl.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                n++
                val f = g.getTrackFormat(i)
                val lang = f.language?.takeIf { it.isNotEmpty() && it != "und" }?.let { Locale(it).displayLanguage } ?: ("Audio " + n)
                val codec = (f.sampleMimeType ?: "").substringAfter('/').uppercase()
                val ch = if (f.channelCount > 0) f.channelCount.toString() + "ch" else ""
                val extra = listOf(codec, ch).filter { it.isNotEmpty() }.joinToString(" ")
                val grp = g
                val idx = i
                out.add(PopItem(lang + (if (extra.isNotEmpty()) "  ($extra)" else ""), g.isTrackSelected(i)) { selectAudio(grp, idx) })
            }
        }
        if (out.isEmpty()) out.add(PopItem(L.t("no_results"), false) { })
        return out
    }

    private fun activatePill() {
        when (pillIdx) {
            0 -> showPopup(0, aspectPop())
            1 -> showPopup(1, speedPop())
            2 -> showPopup(2, subsPop())
            3 -> showPopup(3, audioPop())
            4 -> openMenu()
        }
    }

    private fun openMenuTo(page: () -> MenuPanel.Page) {
        hideHudNow()
        panel.open(rootPage())
        panel.push(page())
        updateCue()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (popupOpen && !panel.isOpen) {
            val r = android.graphics.Rect()
            popScroll.getGlobalVisibleRect(r)
            if (r.contains(ev.rawX.toInt(), ev.rawY.toInt())) return super.dispatchTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP) closePopup(true)
            return true
        }
        if (panel.isOpen) {
            if (ev.action == MotionEvent.ACTION_UP && ev.x < panel.left) { panel.close(); return true }
            return super.dispatchTouchEvent(ev)
        }
        if (locked) {
            if (ev.action == MotionEvent.ACTION_UP) toast(L.t("locked_t"))
            return true
        }
        val r = super.dispatchTouchEvent(ev)
        if (ev.action == MotionEvent.ACTION_UP) showHud(true)
        return r
    }

    // ---------------------------------------------------------------- remote control

    private fun seekBy(ms: Long) {
        val p = player ?: return
        if (syncing) abortSync()
        val d = p.duration
        var t = p.currentPosition + ms
        if (t < 0) t = 0
        if (d != C.TIME_UNSET && t > d - 1000) t = maxOf(d - 1000, 0L)
        p.seekTo(t)
    }

    private val panelKeys = setOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU
    )

    private val playerKeys = setOf(
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP,
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
        KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_PROG_GREEN,
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE
    )

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (popupOpen && !panel.isOpen && k in panelKeys) {
            if (e.action == KeyEvent.ACTION_DOWN) popupKey(k)
            return true
        }
        if (panel.isOpen) {
            if (k !in panelKeys) return super.dispatchKeyEvent(e)
            if (e.action == KeyEvent.ACTION_DOWN) panel.key(k)
            return true
        }
        if (k == KeyEvent.KEYCODE_BACK && hudVisible && controlsMode) {
            if (e.action == KeyEvent.ACTION_DOWN) hideHudNow()
            return true
        }
        if (k !in playerKeys) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) playerKey(k)
        return true
    }

    private fun playerKey(k: Int) {
        val p = player ?: return
        val inControls = hudVisible && controlsMode
        when (k) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (inControls) { if (focusRow == 0) focusIdx = maxOf(0, focusIdx - 1) else pillIdx = maxOf(0, pillIdx - 1); showHud(true) }
                else { seekBy(-10_000); showHud(false) }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (inControls) { if (focusRow == 0) focusIdx = minOf(2, focusIdx + 1) else pillIdx = minOf(4, pillIdx + 1); showHud(true) }
                else { seekBy(10_000); showHud(false) }
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); showHud(inControls) }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(10_000); showHud(inControls) }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (inControls && focusRow == 1) { focusRow = 0; showHud(true) } else openMenu()
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS -> openMenu()
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                focusRow = 1; showHud(true)   // shows the bottom buttons; never changes the picture size
            }
            KeyEvent.KEYCODE_PROG_RED -> { nudge(-500); toast(L.t("delay").substringBefore(" (") + ": " + offsetText()) }
            KeyEvent.KEYCODE_PROG_GREEN -> { nudge(500); toast(L.t("delay").substringBefore(" (") + ": " + offsetText()) }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); showHud(inControls) }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { p.play(); showHud(inControls) }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { p.pause(); showHud(inControls) }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (inControls) { if (focusRow == 0) activateFocus() else activatePill() }
                else { togglePlay(); focusRow = 0; focusIdx = 1; showHud(true) }
            }
        }
    }
}
