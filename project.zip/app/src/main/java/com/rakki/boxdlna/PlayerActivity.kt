package com.rakki.boxdlna

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.WindowManager
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private var loadedSig = ""
    private var gen = 0

    private val ticker = object : Runnable {
        override fun run() {
            player?.let { p ->
                Renderer.posMs = p.currentPosition
                val d = p.duration
                Renderer.durMs = if (d == C.TIME_UNSET) 0L else d
            }
            Renderer.main.postDelayed(this, 500)
        }
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) { sync() }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { sync() }
        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(this@PlayerActivity, "خطأ: " + error.errorCodeName, Toast.LENGTH_LONG).show()
            Renderer.state = "STOPPED"
            Renderer.changed()
            Renderer.main.postDelayed({ finish() }, 3500)
        }
    }

    private fun sync() {
        val p = player ?: return
        val st = when (p.playbackState) {
            Player.STATE_BUFFERING -> "TRANSITIONING"
            Player.STATE_READY -> if (p.playWhenReady) "PLAYING" else "PAUSED_PLAYBACK"
            else -> "STOPPED"
        }
        if (Renderer.state != st) { Renderer.state = st; Renderer.changed() }
        if (p.playbackState == Player.STATE_ENDED) finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = PlayerView(this)
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        setContentView(view)
        applyStyle()

        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.addListener(listener)
        view.player = p
        player = p
        Renderer.activity = this
        Renderer.main.post(ticker)
        load(Renderer.wantPlay, 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        onPlayRequest()
    }

    fun applyStyle() {
        val sv = view.subtitleView ?: return
        val st = SubStyle.get(this)
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, st.size)
        sv.setBottomPaddingFraction(st.pos / 100f)
        sv.setStyle(
            CaptionStyleCompat(
                st.color, SubStyle.bgArgb(st), Color.TRANSPARENT,
                if (st.edge) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE,
                Color.BLACK, null
            )
        )
    }

    fun onPlayRequest() {
        val p = player ?: return
        if (Renderer.signature() != loadedSig) load(true, 0) else p.play()
    }

    fun reloadSubs() {
        val p = player ?: return
        load(p.playWhenReady, p.currentPosition)
    }

    private fun load(autoplay: Boolean, startMs: Long) {
        val u = Renderer.uri
        if (u.isEmpty()) { finish(); return }
        loadedSig = Renderer.signature()
        val g = ++gen
        Thread {
            val sub = Renderer.effectiveManual()
                ?: Renderer.subUrl?.let { SubtitleLoader.fetch(it, cacheDir) }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) start(u, sub, autoplay, startMs, g)
            }
        }.start()
    }

    private fun start(u: String, sub: SubtitleLoader.Sub?, autoplay: Boolean, startMs: Long, g: Int) {
        val p = player ?: return
        if (g != gen) return
        val mb = MediaItem.Builder().setUri(u)
        if (sub != null) {
            mb.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(sub.file))
                        .setMimeType(sub.mime)
                        .setLanguage("ar")
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        p.setMediaItem(mb.build(), startMs)
        p.prepare()
        p.playWhenReady = autoplay
    }

    override fun onDestroy() {
        Renderer.main.removeCallbacks(ticker)
        player?.release()
        player = null
        if (Renderer.activity === this) {
            Renderer.activity = null
            Renderer.wantPlay = false
            if (Renderer.uri.isNotEmpty()) Renderer.state = "STOPPED"
            Renderer.changed()
        }
        super.onDestroy()
    }
}
